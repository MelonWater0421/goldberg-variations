#!/usr/bin/env python3
"""
5-Gate QA Verifier for J.S. Bach's Goldberg Variations Interactive Architecture Lab
(Yunchan Lim · Live at Carnegie Hall, 2025).
"""
from __future__ import annotations

import json
import re
import subprocess
import sys
from pathlib import Path
import librosa
import numpy as np

ROOT = Path(__file__).resolve().parent.parent
JSC = "/System/Library/Frameworks/JavaScriptCore.framework/Versions/A/Helpers/jsc"

# Forbidden symphony-project contamination tokens
FORBIDDEN = re.compile(
    r"\b(?:" + "|".join([
        "brah" + "ms",
        "klei" + "ber",
        "breitkopf" + "_jb",
        "tchai" + "kovsky",
        "plet" + "nev",
        "kara" + "jan",
        "bruck" + "ner",
        "mah" + "ler",
    ]) + r")\b",
    re.I,
)
CJK_RE = re.compile(r"[\u4e00-\u9fff]")

errors: list[str] = []


def err(gate: str, msg: str) -> None:
    errors.append(f"[{gate}] {msg}")


def check_bi(gate: str, obj: dict, zh_k: str, en_k: str, ctx: str) -> None:
    zh = str(obj.get(zh_k, "") or "").strip()
    en = str(obj.get(en_k, "") or "").strip()
    if not zh or not CJK_RE.search(zh):
        err(gate, f"{ctx}: missing/non-Chinese {zh_k!r}")
    if not en:
        err(gate, f"{ctx}: missing {en_k!r}")


def main() -> int:
    print("Running Gate 1a: JSC syntax & Zero-Contamination scan...")
    for js in ("engine.js", "app.js", "data.js"):
        res = subprocess.run([JSC, "-e", f"new Function(read({json.dumps(str(ROOT / js))}));"], capture_output=True, text=True)
        if res.returncode != 0:
            err("Gate 1a", f"{js} syntax error: {res.stderr.strip()}")

    exec_res = subprocess.run(
        [JSC, "-e", "var window = globalThis;", str(ROOT / "data.js"), str(ROOT / "engine.js"), "-e",
         "if (!window.GOLDBERG_DATA || window.GOLDBERG_DATA.tracks.length !== 32) throw new Error('Bad GOLDBERG_DATA');"],
        capture_output=True, text=True,
    )
    if exec_res.returncode != 0:
        err("Gate 1a", f"Runtime load check failed: {exec_res.stderr.strip()}")

    scan_files = [
        ROOT / "index.html", ROOT / "style.css", ROOT / "engine.js",
        ROOT / "app.js", ROOT / "serve.py", ROOT / "data.js",
        *(ROOT / "tools").glob("*.py"),
    ]
    if (ROOT / "README.md").exists():
        scan_files.append(ROOT / "README.md")
    for p in scan_files:
        if p.name == "verify_atlas.py":
            continue
        m = FORBIDDEN.search(p.read_text(encoding="utf-8", errors="ignore"))
        if m:
            err("Gate 1a", f"Contamination token {m.group(0)!r} in {p.relative_to(ROOT)}")

    raw = (ROOT / "data.js").read_text(encoding="utf-8")
    D = json.loads(raw.split("=", 1)[1].strip().rstrip(";"))

    print("Running Gate 1b: 32 MP3 files, monotonic pillars/stages/cues & beat-grid bounds...")
    if len(D.get("groundPillars", [])) != 32:
        err("Gate 1b", f"Expected 32 groundPillars, got {len(D.get('groundPillars', []))}")
    if len(D.get("harmonicQuadrants", [])) != 4:
        err("Gate 1b", f"Expected 4 harmonicQuadrants, got {len(D.get('harmonicQuadrants', []))}")
    for qd in D.get("harmonicQuadrants", []):
        check_bi("Gate 2", qd, "name", "name_en", f"quadrant.{qd.get('id')}")
        check_bi("Gate 2", qd, "tonality", "tonality_en", f"quadrant.{qd.get('id')}")
        check_bi("Gate 2", qd, "feel", "feel_en", f"quadrant.{qd.get('id')}")
    if len(D.get("tracks", [])) != 32:
        err("Gate 1b", f"Expected 32 tracks, got {len(D.get('tracks', []))}")

    for tr in D["tracks"]:
        tid = tr["id"]
        mp3 = ROOT / tr["audio"]
        if not mp3.exists() or mp3.stat().st_size < 100_000:
            err("Gate 1b", f"Track {tid:02d} missing/tiny MP3 {tr['audio']}")
        if mp3.exists() and mp3.stat().st_size >= 30 * 1024 * 1024:
            err("Gate 1b", f"Track {tid:02d} MP3 exceeds 30MB")
        s0, s1, dur = tr["musicStartSec"], tr["musicEndSec"], tr["duration"]
        if not (0.0 <= s0 < s1 <= dur):
            err("Gate 1b", f"Track {tid:02d} invalid bounds s0={s0}, s1={s1}, dur={dur}")

        p_secs = [p["sec"] for p in tr["pillars"]]
        if any(p_secs[k] <= p_secs[k - 1] for k in range(1, len(p_secs))):
            err("Gate 1b", f"Track {tid:02d} non-monotonic pillars")

        st_secs = [s["start"] for s in tr["stages"]]
        if len(st_secs) < 4 or any(st_secs[k] <= st_secs[k - 1] for k in range(1, len(st_secs))):
            err("Gate 1b", f"Track {tid:02d} invalid/non-monotonic stages: {st_secs}")

        c_secs = [c["sec"] for c in tr["cues"]]
        if len(c_secs) < 3 or any(c_secs[k] <= c_secs[k - 1] for k in range(1, len(c_secs))):
            err("Gate 1b", f"Track {tid:02d} invalid/non-monotonic cues: {c_secs}")

        if not tr["notes"] or len(tr["beatGridSecs"]) < 10:
            err("Gate 1b", f"Track {tid:02d} empty notes or beatGridSecs")

    print("Running Gate 2: 100% ZH/EN bilingual completeness across Primer, 32 Chapters, Glossary & Threads...")
    check_bi("Gate 2", D["metadata"], "title", "title_en", "metadata")
    check_bi("Gate 2", D["primer"], "headline", "headline_en", "primer")
    check_bi("Gate 2", D["primer"], "intro", "intro_en", "primer")
    if len(D["primer"].get("steps", [])) != 3:
        err("Gate 2", "Primer must have 3 interactive steps")
    for st in D["primer"].get("steps", []):
        check_bi("Gate 2", st, "title", "title_en", f"primer.{st.get('id')}")
        check_bi("Gate 2", st, "body", "body_en", f"primer.{st.get('id')}")

    if len(D.get("glossary", [])) < 12:
        err("Gate 2", f"Glossary count {len(D.get('glossary', []))} < 12")
    for g in D.get("glossary", []):
        check_bi("Gate 2", g, "term", "term_en", "glossary")
        check_bi("Gate 2", g, "definition", "definition_en", "glossary")

    if len(D.get("threads", [])) < 6:
        err("Gate 2", f"Threads count {len(D.get('threads', []))} < 6")
    for th in D.get("threads", []):
        check_bi("Gate 2", th, "title", "title_en", "threads")
        check_bi("Gate 2", th, "summary", "summary_en", "threads")

    for tr in D["tracks"]:
        ctx = f"Track {tr['id']:02d}"
        for zh_k, en_k in [
            ("title", "title_en"), ("subtitle", "subtitle_en"),
            ("noviceHook", "noviceHook_en"), ("recipe", "recipe_en"), ("limNote", "limNote_en"),
        ]:
            check_bi("Gate 2", tr, zh_k, en_k, ctx)
        astro = tr.get("astro") or {}
        for zh_k, en_k in [
            ("disguiseType", "disguiseType_en"), ("whereIsTheme", "whereIsTheme_en"),
            ("canonRule", "canonRule_en"), ("modSecret", "modSecret_en"),
        ]:
            check_bi("Gate 2", astro, zh_k, en_k, f"{ctx}.astro")
        if len(tr.get("skeletonNotes", [])) != len(tr.get("pillars", [])):
            err("Gate 1b", f"{ctx}: skeletonNotes count {len(tr.get('skeletonNotes', []))} != pillars {len(tr.get('pillars', []))}")
        if (tr["category"] == "canon") != (astro.get("canonDelayQ") is not None):
            err("Gate 5", f"{ctx}: canonDelayQ presence mismatch with category={tr['category']}")
        for vm in tr["voicesMeta"]:
            check_bi("Gate 2", vm, "name", "name_en", f"{ctx}.voicesMeta")
            check_bi("Gate 2", vm, "role", "role_en", f"{ctx}.voicesMeta")
        for s in tr["stages"]:
            check_bi("Gate 2", s, "title", "title_en", f"{ctx}.{s['id']}")
            check_bi("Gate 2", s, "desc", "desc_en", f"{ctx}.{s['id']}")
            check_bi("Gate 2", s, "focus", "focus_en", f"{ctx}.{s['id']}")
        for c in tr["cues"]:
            check_bi("Gate 2", c, "label", "label_en", f"{ctx}.cue")

    print("Running Gate 3: Acoustic & CQT DTW verification on key Carnegie Hall landmarks...")
    mean_cos_all = float(np.mean([t["meanCosine"] for t in D["tracks"]]))
    if mean_cos_all < 0.80:
        err("Gate 3", f"Mean CQT cosine similarity too low: {mean_cos_all:.4f}")
    # Spot-check 50 Hz acoustic energy at stage starts on sample landmark tracks (0, 1, 15, 16, 25, 30, 31)
    for sample_id in (0, 1, 15, 16, 25, 30, 31):
        tr = D["tracks"][sample_id]
        y, sr = librosa.load(str(ROOT / tr["audio"]), sr=22050, mono=True)
        rms50 = librosa.feature.rms(y=y, frame_length=1024, hop_length=441)[0]
        db50 = 20.0 * np.log10(np.maximum(rms50, 1e-8))
        db50 -= db50.max()
        for s in tr["stages"]:
            f_idx = int(round(s["start"] * 50))
            win = db50[max(0, f_idx - 15):min(len(db50), f_idx + 20)]
            if len(win) == 0 or float(win.max()) < -42.0:
                err("Gate 3", f"Track {sample_id:02d} {s['id']} at {s['start']}s falls in silence ({float(win.max()) if len(win) else -99:.1f} dB)")

    print("Running Gate 4 & Gate 5: Goldberg Variations Architectural & Score-Truth Guardrails...")
    # Check 9 ascending canons at 3,6,9,12,15,18,21,24,27
    for k, var_num in enumerate(range(3, 30, 3), start=1):
        tr = D["tracks"][var_num]
        if tr["category"] != "canon" or tr["canonInterval"] != k:
            err("Gate 5", f"Var. {var_num} must be canon at interval {k}, got cat={tr['category']}, interval={tr['canonInterval']}")
        if (var_num in (12, 15)) != bool(tr["canonInverted"]):
            err("Gate 5", f"Var. {var_num} canonInverted mismatch")
    # Check 3 G-minor variations (15, 21, 25)
    minor_ids = [t["id"] for t in D["tracks"] if t["keyMode"] == "G minor"]
    if minor_ids != [15, 21, 25]:
        err("Gate 5", f"Expected G minor tracks [15, 21, 25], got {minor_ids}")
    # Check Lim Carnegie Hall repeat truth: AABB on 0..30, AB on 31 (Aria da capo)
    for tid in range(31):
        if D["tracks"][tid]["repeatTopology"] != "AABB":
            err("Gate 5", f"Track {tid:02d} expected AABB in Lim Carnegie Hall, got {D['tracks'][tid]['repeatTopology']}")
    if D["tracks"][31]["repeatTopology"] != "AB":
        err("Gate 5", f"Track 31 (Aria da capo) expected AB (repeat-less), got {D['tracks'][31]['repeatTopology']}")
    if D["tracks"][30]["category"] != "quodlibet":
        err("Gate 5", "Track 30 must be quodlibet")

    if errors:
        print(f"\nFAILED with {len(errors)} error(s):")
        for e in errors[:30]:
            print(" ", e)
        return 1

    print(
        f"\nALL 5 GATES PASSED (0 errors)! "
        f"tracks=32, stages={D['metadata']['totalStages']}, cues={D['metadata']['totalCues']}, "
        f"mean_cqt_cosine={mean_cos_all:.4f}, glossary={len(D['glossary'])}, threads={len(D['threads'])}"
    )
    return 0


if __name__ == "__main__":
    sys.exit(main())
