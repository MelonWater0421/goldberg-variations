#!/usr/bin/env python3
"""
Score extraction, Carnegie Hall applause-aware boundary detection, empirical repeat-topology
identification (AABB / AB / AAB / ABB), and 20 Hz CQT chroma DTW alignment across all 32
movements of J.S. Bach's Goldberg Variations, BWV 988 (Yunchan Lim, Live at Carnegie Hall 2025).
"""
from __future__ import annotations

import concurrent.futures
import json
from pathlib import Path
import librosa
import mido
import numpy as np

ROOT = Path(__file__).resolve().parent.parent
SCORES = ROOT / "tools" / "scores"
ASSETS = ROOT / "assets"
CACHE = ROOT / "tools" / "score-cache"
CACHE.mkdir(parents=True, exist_ok=True)

# Verified exact OpenGoldberg CC0 Score (IMSLP #229423, 58 pp.) 1-based page numbers
PDF_URL = "https://s9.imslp.org/files/imglnks/usimg/4/49/IMSLP229423-PMLP02982-js-bach-goldberg-variations.pdf"
PDF_PAGES = {
    0: 2, 1: 4, 2: 6, 3: 7, 4: 9, 5: 10, 6: 12, 7: 13,
    8: 15, 9: 17, 10: 18, 11: 19, 12: 21, 13: 23, 14: 25, 15: 28,
    16: 30, 17: 32, 18: 34, 19: 35, 20: 36, 21: 38, 22: 39, 23: 40,
    24: 42, 25: 44, 26: 47, 27: 49, 28: 51, 29: 54, 30: 56, 31: 57,
}

# Canonical 32-Pillar Harmonic Ground Bass (Soggetto) of the Goldberg Variations
# Each entry: (pillar_1_to_32, note_zh, note_en, solfege, degree, phrase_group 1..4)
GROUND_PILLARS = [
    # Phrase I (1-8): Tonic G major expanse -> Half/Tonic cadence
    (1, "G", "G3", "Do", "I", 1), (2, "F#", "F#3", "Si", "V6", 1),
    (3, "E", "E3", "La", "vi", 1), (4, "D", "D3", "Sol", "iii6 / V", 1),
    (5, "B", "B2", "Mi", "I6", 1), (6, "C", "C3", "Fa", "IV", 1),
    (7, "D", "D3", "Sol", "V", 1), (8, "G", "G2", "Do", "I", 1),
    # Phrase II (9-16): Modulation to the Dominant D major
    (9, "G", "G3", "Do", "I", 2), (10, "F#", "F#3", "Si", "V6", 2),
    (11, "E", "E3", "La", "vi", 2), (12, "D", "D3", "Sol", "I6/4(D)", 2),
    (13, "B", "B2", "Mi", "ii6(D)", 2), (14, "C#", "C#3", "升Fa", "V6/5/V", 2),
    (15, "D", "D3", "Sol", "V(D)→I", 2), (16, "A→D", "A2/D3", "Re→Sol", "V:PAC", 2),
    # Phrase III (17-24): Departure from D major toward E minor (vi)
    (17, "D", "D3", "Sol", "V", 3), (18, "B", "B2", "Mi", "V6/vi", 3),
    (19, "C", "C3", "Fa", "IV6", 3), (20, "B", "B2", "Mi", "V/vi", 3),
    (21, "G", "G2", "Do", "III(e)", 3), (22, "F#", "F#2", "Si", "ii°6(e)", 3),
    (23, "B", "B2", "Mi", "V(e)", 3), (24, "E", "E2", "La", "vi(e)", 3),
    # Phrase IV (25-32): Chromatic/Subdominant Descent & Homecoming to G
    (25, "C", "C3", "Fa", "IV", 4), (26, "B", "B2", "Mi", "I6", 4),
    (27, "A", "A2", "Re", "ii", 4), (28, "G", "G2", "Do", "I / V4/2", 4),
    (29, "C", "C3", "Fa", "IV6", 4), (30, "D", "D3", "Sol", "I6/4–V", 4),
    (31, "D", "D2", "Sol", "V7", 4), (32, "G", "G2", "Do", "I:PAC", 4),
]


def parse_midi_score(idx: int) -> dict:
    """Parse voice-separated BWV 988 MIDI into canonical voices and A1/A2/B1/B2 pillar map."""
    mf = mido.MidiFile(SCORES / f"track-{idx:02d}.mid")
    tpb = mf.ticks_per_beat

    raw_voices = []
    for ti, tr in enumerate(mf.tracks):
        at = 0
        open_notes: dict[tuple[int, int], int] = {}
        notes = []
        for m in tr:
            at += m.time
            if m.type == "note_on" and m.velocity > 0:
                open_notes[(m.channel, m.note)] = at
            elif m.type in ("note_off", "note_on") and (m.type == "note_off" or m.velocity == 0):
                st = open_notes.pop((m.channel, m.note), None)
                if st is not None and at > st:
                    notes.append([round(st / tpb, 4), round((at - st) / tpb, 4), int(m.note)])
        if notes:
            notes.sort(key=lambda x: (x[0], -x[2]))
            med_pitch = float(np.median([n[2] for n in notes]))
            raw_voices.append({"origTrack": ti, "medianPitch": med_pitch, "notes": notes})

    # Order voices: keep MIDI track order for canons where leader/follower cross at unison/2nd,
    # ensuring Bass is always the last voice (lowest medianPitch if >2 voices).
    if len(raw_voices) >= 3:
        # Check if last track is clearly the bass
        bass_idx = int(np.argmin([v["medianPitch"] for v in raw_voices]))
        upper = [v for k, v in enumerate(raw_voices) if k != bass_idx]
        # Keep upper in original MIDI order (Track 1 = Canon Leader/Soprano, Track 2 = Follower/Alto)
        ordered = upper + [raw_voices[bass_idx]]
    else:
        # 2 voices: ensure higher median is index 0, lower median is index 1 (except Var 27 canon at 9th)
        if raw_voices[0]["medianPitch"] < raw_voices[1]["medianPitch"]:
            ordered = [raw_voices[1], raw_voices[0]]
        else:
            ordered = raw_voices

    # Extract meter
    merged = mido.merge_tracks(mf.tracks)
    at = 0
    ts_changes = []
    for m in merged:
        at += m.time
        if m.type == "time_signature":
            ts_changes.append((round(at / tpb, 4), f"{m.numerator}/{m.denominator}", m.numerator * (4.0 / m.denominator)))
    meter = ts_changes[0][1] if ts_changes else "3/4"

    max_q = max(n[0] + n[1] for v in ordered for n in v["notes"])

    # Exact A1, A2, B1, B2 quarter-note spans in the 64-pillar unrolled MIDI
    if idx == 16:
        # French Overture: Part A = 62.0 q x 2 = [0..62), [62..124); Part B = [124..173.25), [173.25..max_q]
        # Verify exact shift in B: 32 bars of 3/8 (48 q) + final 4/4 cadence
        # Earlier self-similarity check showed LB = 48.0..49.25: let's compute exact onset shift in [124..max_q]!
        onsets = {(round(n[0], 3), n[2]) for v in ordered for n in v["notes"] if n[0] >= 124.0}
        best_lb, best_hit = 49.25, -1.0
        for cand in [x * 0.25 for x in range(180, 204)]:
            pts = [(q, p) for q, p in onsets if 124.0 <= q < 124.0 + cand - 0.5]
            if pts:
                h = sum(1 for q, p in pts if (round(q + cand, 3), p) in onsets) / len(pts)
                if h > best_hit:
                    best_hit, best_lb = h, cand
        spans = {
            "A1": (0.0, 62.0),
            "A2": (62.0, 124.0),
            "B1": (124.0, round(124.0 + best_lb, 4)),
            "B2": (round(124.0 + best_lb, 4), round(max_q, 4)),
        }
    elif idx == 30:
        # Quodlibet: 0.5q (1/8) pickup, then 32.0q per 16-pillar half
        spans = {
            "A1": (0.0, 32.5),
            "A2": (32.5, 64.5),
            "B1": (64.5, 96.5),
            "B2": (96.5, round(max_q, 4)),
        }
    else:
        # Standard symmetrical 4-pass MIDI (A1, A2, B1, B2)
        # Round total nominal quarter length to nearest integer multiple of 16
        nominal_la = round(max_q / 4.0 * 2) / 2.0
        spans = {
            "A1": (0.0, nominal_la),
            "A2": (nominal_la, 2.0 * nominal_la),
            "B1": (2.0 * nominal_la, 3.0 * nominal_la),
            "B2": (3.0 * nominal_la, max(max_q, 4.0 * nominal_la)),
        }

    return {
        "index": idx,
        "meter": meter if idx != 16 else "4/4 → 3/8",
        "maxQ": round(max_q, 4),
        "spans": spans,
        "voices": [v["notes"] for v in ordered],
    }


def slice_topology(score: dict, topo: str) -> tuple[list[list[float]], list[dict], float]:
    """
    Build note list & 16-pillar-per-section markers for a candidate repeat topology:
      'AABB' -> A1, A2, B1, B2 (64 pillars)
      'AB'   -> A1, B1 (32 pillars)
      'AAB'  -> A1, A2, B1 (48 pillars)
      'ABB'  -> A1, B1, B2 (48 pillars)
    Returns (notes_out, pillar_events, total_q)
      where each note is [q_start, q_dur, midi, voice_idx]
      and each pillar_event is {'seq': 1..N, 'pillar': 1..32, 'pass': 'A1'|'A2'|'B1'|'B2', 'q': float}
    """
    order_map = {
        "AABB": ["A1", "A2", "B1", "B2"],
        "AB": ["A1", "B1"],
        "AAB": ["A1", "A2", "B1"],
        "ABB": ["A1", "B1", "B2"],
    }
    secs = order_map[topo]
    spans = score["spans"]
    q_cursor = 0.0
    notes_out = []
    pillars_out = []
    seq = 0

    for sname in secs:
        q0, q1 = spans[sname]
        slen = q1 - q0
        # Handle Quodlibet 0.5q pickup on A1 cleanly
        pickup = 0.5 if (score["index"] == 30 and sname == "A1") else 0.0
        body_len = slen - pickup
        p_base = 1 if sname.startswith("A") else 17
        for p_off in range(16):
            seq += 1
            pq = q_cursor + (0.0 if (p_off == 0 and pickup > 0) else pickup + p_off * (body_len / 16.0))
            pillars_out.append({
                "seq": seq,
                "pillar": p_base + p_off,
                "pass": sname,
                "q": round(pq, 4),
            })

        for vi, vnotes in enumerate(score["voices"]):
            for st, dur, midi in vnotes:
                if q0 - 0.02 <= st < q1 - 0.02:
                    clipped_dur = min(dur, q1 - st)
                    if clipped_dur > 0.01:
                        notes_out.append([round(q_cursor + (st - q0), 4), round(clipped_dur, 4), midi, vi])
        q_cursor += slen

    notes_out.sort(key=lambda x: (x[0], x[3], -x[2]))
    return notes_out, pillars_out, round(q_cursor, 4)


def render_score_features(notes: list[list[float]], total_q: float, n_frames: int, hop_sec: float) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Render 12-D CQT-like chroma + energy + onset envelope on n_frames over [0, total_q]."""
    step = total_q / max(1, n_frames)
    chroma = np.zeros((12, n_frames), dtype=np.float32)
    energy = np.zeros(n_frames, dtype=np.float32)
    onset = np.zeros(n_frames, dtype=np.float32)
    for st, dur, midi, _vi in notes:
        left = max(0, min(n_frames - 1, int(st / step)))
        right = min(n_frames, max(left + 1, int(np.ceil((st + dur) / step))))
        # Piano natural string decay (~1.1s time constant)
        decay = np.exp(-np.arange(right - left) * hop_sec / 1.1).astype(np.float32)
        chroma[midi % 12, left:right] += decay
        energy[left:right] += decay
        onset[left] += 1.0
    chroma /= np.maximum(1e-8, np.linalg.norm(chroma, axis=0))
    energy = np.log1p(energy)
    energy = (energy - energy.min()) / (np.ptp(energy) + 1e-8)
    onset = np.clip(onset / (np.percentile(onset, 98) + 1e-8), 0.0, 1.0)
    return chroma, energy, onset


def detect_piano_bounds(y: np.ndarray, sr: int, hop50: int) -> tuple[float, float, bool]:
    """
    Detect true piano musicStartSec (s0) and musicEndSec (s1), stripping pre-attack hall silence
    and any post-performance Carnegie Hall applause!
    """
    duration = len(y) / sr
    rms50 = librosa.feature.rms(y=y, frame_length=1024, hop_length=hop50)[0]
    flat50 = librosa.feature.spectral_flatness(y=y, n_fft=1024, hop_length=hop50)[0]
    db50 = 20.0 * np.log10(np.maximum(rms50, 1e-8))
    db50 -= db50.max()

    # Applause detector in final 25% of track: sustained broadband noise (flatness > 0.08 & db > -38)
    tail_start = int(len(db50) * 0.72)
    has_applause = False
    applause_frame = None
    # Smooth flatness over 0.5s (25 frames)
    if len(flat50) > 50:
        ker = np.ones(25) / 25.0
        s_flat = np.convolve(flat50, ker, mode="same")
        s_db = np.convolve(db50, ker, mode="same")
        cand_app = np.where((np.arange(len(db50)) >= tail_start) & (s_flat > 0.075) & (s_db > -34.0))[0]
        if len(cand_app) >= 25:
            has_applause = True
            # Walk back from applause onset to local minimum of db50 (the breath of silence before applause!)
            app0 = int(cand_app[0])
            search_lo = max(int(len(db50) * 0.55), app0 - 400)  # up to 8s before applause
            quiet_idx = search_lo + int(np.argmin(db50[search_lo:app0 + 1]))
            applause_frame = quiet_idx

    end_limit = applause_frame if applause_frame is not None else len(db50)
    active = np.where(db50[:end_limit] > -46.0)[0]
    if len(active) == 0:
        active = np.where(db50[:end_limit] > -54.0)[0]

    s0 = float(max(0.0, active[0] * hop50 / sr - 0.04)) if len(active) else 0.0
    # For piano fade-out at end of movement, include quiet resonance down to -54 dB before applause/end
    active_tail = np.where(db50[:end_limit] > -53.0)[0]
    s1_raw = float(active_tail[-1] * hop50 / sr + 0.12) if len(active_tail) else duration - 0.05
    s1 = float(min(duration - 0.04, (applause_frame * hop50 / sr - 0.08) if applause_frame else s1_raw))
    return round(s0, 3), round(max(s0 + 1.0, s1), 3), has_applause


def align_one_track(idx: int) -> dict:
    score = parse_midi_score(idx)
    mp3_path = ASSETS / f"track-{idx:02d}.mp3"
    sr = 22050
    hop50 = 441   # 0.02s = 50 Hz
    hop20 = 1102  # ~0.05s = 20 Hz

    y, _ = librosa.load(str(mp3_path), sr=sr, mono=True)
    duration = float(len(y) / sr)
    s0, s1, has_applause = detect_piano_bounds(y, sr, hop50)

    # 240-point waveform RMS across full audio duration
    rms_full = librosa.feature.rms(y=y, frame_length=1024, hop_length=hop50)[0]
    bins = np.array_split(rms_full, 240)
    vals = np.array([float(np.sqrt(np.mean(b ** 2))) if len(b) else 0.0 for b in bins])
    vmax = float(np.percentile(vals, 99.5)) if vals.max() > 0 else 1.0
    waveform = [round(float(np.clip(0.03 + 0.97 * (v / vmax), 0.03, 1.0)), 3) for v in vals]

    # Audio features on [s0, s1]
    y_seg = y[max(0, int(s0 * sr)):min(len(y), int(s1 * sr))]
    tuning = float(librosa.estimate_tuning(y=y_seg[:min(len(y_seg), sr * 60)], sr=sr))
    cqt_b = librosa.feature.chroma_cqt(
        y=y_seg, sr=sr, hop_length=hop20, tuning=tuning,
        fmin=librosa.note_to_hz("C1"), n_chroma=12
    ).astype(np.float32)
    cqt_b /= np.maximum(1e-8, np.linalg.norm(cqt_b, axis=0))
    rms_b = librosa.feature.rms(y=y_seg, frame_length=2048, hop_length=hop20)[0].astype(np.float32)
    m = min(cqt_b.shape[1], len(rms_b))
    cqt_b, rms_b = cqt_b[:, :m], rms_b[:m]
    log_r = np.log1p(rms_b * 100.0)
    log_r = (log_r - log_r.min()) / (np.ptp(log_r) + 1e-8)
    nov = np.maximum(0.0, np.diff(log_r, prepend=log_r[0]))
    nov = np.clip(nov / (np.percentile(nov, 98) + 1e-8), 0.0, 1.0)
    Y = np.vstack([cqt_b, log_r * 0.25, nov * 0.15])
    Y /= np.maximum(1e-8, np.linalg.norm(Y, axis=0))
    hop20_sec = hop20 / sr

    # Test all 4 repeat topologies empirically!
    # Note: Var. 16 Part A is grave (slow) and Part B is allegro 3/8 (fast), so allow wider band_rad=0.32 on idx==16
    band_rad = 0.34 if idx == 16 else 0.22
    topo_scores = {}
    topo_results = {}

    for topo in ("AABB", "AB", "AAB", "ABB"):
        notes_t, pillars_t, total_q = slice_topology(score, topo)
        # For Var. 16, pre-warp score time because Grave 4/4 quarter is ~2.2x slower than 3/8 quarter!
        if idx == 16:
            a_end_q = 124.0 if "A2" in [p["pass"] for p in pillars_t] else 62.0
            def warp_q16(q_val: float, ae: float = a_end_q) -> float:
                return q_val * 2.15 if q_val <= ae else ae * 2.15 + (q_val - ae) * 1.0
            w_notes = [[warp_q16(st), warp_q16(st + du) - warp_q16(st), mi, vi] for st, du, mi, vi in notes_t]
            w_total = warp_q16(total_q)
            ch, en, ons = render_score_features(w_notes, w_total, m, hop20_sec)
        else:
            w_total = total_q
            ch, en, ons = render_score_features(notes_t, total_q, m, hop20_sec)

        X = np.vstack([ch, en * 0.25, ons * 0.15])
        X /= np.maximum(1e-8, np.linalg.norm(X, axis=0))
        C = np.asarray(1.0 - X.T @ Y, dtype=np.float32)
        D_mat, wp = librosa.sequence.dtw(
            C=C,
            step_sizes_sigma=np.array([[1, 1], [1, 2], [2, 1], [1, 3], [3, 1]]),
            weights_mul=np.array([1.0, 1.04, 1.04, 1.12, 1.12]),
            global_constraints=True,
            band_rad=band_rad,
        )
        wp = wp[::-1]
        mean_cos = float(np.mean(1.0 - C[wp[:, 0], wp[:, 1]]))
        norm_cost = float(D_mat[-1, -1] / len(wp))
        topo_scores[topo] = round(mean_cos, 4)
        topo_results[topo] = (mean_cos, norm_cost, wp, notes_t, pillars_t, total_q, w_total)

    # Pick topology with highest mean CQT cosine similarity!
    best_topo = max(topo_results.keys(), key=lambda k: topo_results[k][0])
    mean_cos, norm_cost, wp, notes_best, pillars_best, total_q, w_total = topo_results[best_topo]

    # Map score q -> audio seconds smoothly & monotonically
    uniq, uidx = np.unique(wp[:, 0], return_index=True)
    frame_wqs = np.linspace(0.0, w_total, m, endpoint=False)
    frame_secs = s0 + wp[uidx, 1] * hop20_sec

    if idx == 16:
        a_end_q = 124.0 if "A2" in [p["pass"] for p in pillars_best] else 62.0
        def q_to_wq(qv: np.ndarray) -> np.ndarray:
            return np.where(qv <= a_end_q, qv * 2.15, a_end_q * 2.15 + (qv - a_end_q))
    else:
        def q_to_wq(qv: np.ndarray) -> np.ndarray:
            return qv

    # Pillar timestamps (64, 48, or 32 pillars depending on Lim's repeat choice)
    p_qs = np.array([p["q"] for p in pillars_best], dtype=np.float64)
    p_secs = np.interp(q_to_wq(p_qs), frame_wqs[uniq], frame_secs)
    p_secs[0] = s0
    for k in range(1, len(p_secs)):
        p_secs[k] = max(p_secs[k], p_secs[k - 1] + 0.08)
    for k in range(len(p_secs) - 1, -1, -1):
        p_secs[k] = min(p_secs[k], s1 - (len(p_secs) - k) * 0.08)

    for p_obj, sec_val in zip(pillars_best, p_secs):
        p_obj["sec"] = round(float(sec_val), 3)

    # Compact quarter-beat warp grid (every 1.0 q from 0 to total_q) so client-side ribbon & 88-key
    # keyboard interpolate note start/end to exact audio millisecond!
    grid_n = int(np.ceil(total_q)) + 1
    grid_qs = np.linspace(0.0, total_q, grid_n)
    grid_secs = np.interp(q_to_wq(grid_qs), frame_wqs[uniq], frame_secs)
    grid_secs[0] = s0
    grid_secs[-1] = s1
    for k in range(1, len(grid_secs)):
        grid_secs[k] = max(grid_secs[k], grid_secs[k - 1] + 0.01)

    # Check voice crossings (where upper voice dips below lower voice simultaneously)
    crossings = 0
    if len(score["voices"]) >= 2:
        v0 = [n for n in notes_best if n[3] == 0]
        v1 = [n for n in notes_best if n[3] == 1]
        j = 0
        for st0, du0, m0, _ in v0:
            while j < len(v1) and v1[j][0] + v1[j][1] <= st0:
                j += 1
            k = j
            while k < len(v1) and v1[k][0] < st0 + du0:
                if m0 < v1[k][2]:
                    crossings += 1
                    break
                k += 1

    return {
        "id": idx,
        "audio": f"assets/track-{idx:02d}.mp3",
        "duration": round(duration, 3),
        "musicStartSec": s0,
        "musicEndSec": s1,
        "hasApplause": has_applause,
        "tuningSemitones": round(tuning, 3),
        "meter": score["meter"],
        "voiceCount": len(score["voices"]),
        "voiceCrossings": crossings,
        "repeatTopology": best_topo,
        "topologyScores": topo_scores,
        "meanCosine": round(mean_cos, 4),
        "totalQ": total_q,
        "scorePage": PDF_PAGES[idx],
        "scoreUrl": f"{PDF_URL}#page={PDF_PAGES[idx]}",
        "waveform": waveform,
        "pillars": pillars_best,
        "beatGridQStep": round(total_q / max(1, grid_n - 1), 5),
        "beatGridSecs": [round(float(x), 3) for x in grid_secs],
        "notes": [[round(st, 3), round(du, 3), mi, vi] for st, du, mi, vi in notes_best],
    }


def main():
    print("Aligning all 32 Yunchan Lim Carnegie Hall tracks (20 Hz CQT DTW + empirical repeat detection)...")
    with concurrent.futures.ProcessPoolExecutor(max_workers=6) as ex:
        tracks = list(ex.map(align_one_track, range(32)))

    out_path = CACHE / "aligned_tracks.json"
    out_path.write_text(json.dumps({
        "pdfUrl": PDF_URL,
        "groundPillars": GROUND_PILLARS,
        "tracks": tracks,
    }, ensure_ascii=False))

    # Also write lightweight summary WITHOUT note arrays for fast inspection by corpus subagents
    summary = []
    for t in tracks:
        pass_starts = {}
        for p in t["pillars"]:
            if p["pass"] not in pass_starts:
                pass_starts[p["pass"]] = p["sec"]
        summary.append({
            "id": t["id"],
            "duration": t["duration"],
            "musicStartSec": t["musicStartSec"],
            "musicEndSec": t["musicEndSec"],
            "hasApplause": t["hasApplause"],
            "meter": t["meter"],
            "voiceCount": t["voiceCount"],
            "voiceCrossings": t["voiceCrossings"],
            "repeatTopology": t["repeatTopology"],
            "topologyScores": t["topologyScores"],
            "meanCosine": t["meanCosine"],
            "pillarCount": len(t["pillars"]),
            "passStarts": pass_starts,
            "scorePage": t["scorePage"],
            "noteCount": len(t["notes"]),
        })
    (CACHE / "aligned_summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2))

    print(f"\nSaved {out_path} ({out_path.stat().st_size / 1024 / 1024:.2f} MB)")
    for s in summary:
        print(
            f"  [{s['id']:02d}] dur={s['duration']:6.2f}s [{s['musicStartSec']:5.2f}..{s['musicEndSec']:6.2f}] "
            f"topo={s['repeatTopology']:4s} cos={s['meanCosine']:.3f} voices={s['voiceCount']} "
            f"cross={s['voiceCrossings']:3d} passes={s['passStarts']} app={s['hasApplause']} scores={s['topologyScores']}"
        )


if __name__ == "__main__":
    main()
