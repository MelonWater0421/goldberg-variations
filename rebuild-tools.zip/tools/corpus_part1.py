# -*- coding: utf-8 -*-
"""
Bilingual (ZH/EN) Pedagogical Corpus — Part I (Primer + Chapters 0..15, Wing I)
J.S. Bach: Goldberg Variations, BWV 988
Performance Reference: Yunchan Lim — Live at Carnegie Hall, New York (April 25, 2025 · Decca Classics)
"""

PRIMER = {
    "headline": "从零听懂《哥德堡变奏曲》：不是把旋律改头换面，而是在同一座地基上盖三十座奇境",
    "headline_en": "Goldberg from Zero: Not Disguising a Tune, Watch Thirty Worlds Rise on One Foundation",
    "intro": (
        "第一次听《哥德堡变奏曲》的人，几乎都会掉进同一个温柔的陷阱：拼命在第一变奏里寻找开头《咏叹调》那支熟悉的旋律，"
        "结果五秒钟就迷路了——旋律去哪儿了？答案藏在脚下，不在头顶！巴赫没有对表面的“歌调”做变奏，而是保留了地下室里"
        "整整 32 根承重金柱（低音与和声骨架）。就像一位神级建筑师：地基的柱距分毫不改，上面却接连筑起波兰舞厅、森林猎号、"
        "水上倒影迷宫与星空长笛圣殿。不需要认识一个五线谱音符，只要掌握下面三个听觉机关，整座巴赫圣殿就会在你耳边瞬间透亮。"
    ),
    "intro_en": (
        "Almost every first-time listener falls into the same gentle trap: hunting in Variation 1 for the singing "
        "melody of the opening Aria, only to get lost within five seconds. Where did the tune go? Look beneath your feet, "
        "not overhead! Bach never varies the surface melody—he preserves the subterranean blueprint of 32 load-bearing "
        "harmonic pillars. Like a master architect keeping the exact column grid while erecting thirty radically different "
        "rooms above—a Polish ballroom, a sunlit courtyard, a hall of water reflections, a nocturnal flute sanctuary—Bach "
        "builds from the ground up. You do not need to read a single note of sheet music: unlock the three ear-keys below "
        "and the entire cathedral lights up."
    ),
    "steps": [
        {
            "id": "ground",
            "stepNum": 1,
            "title": "机关一 · 三十二根承重金柱",
            "title_en": "Key 1 · The Thirty-Two Golden Pillars",
            "tagline": "别抓头顶飘走的云，去踩脚下稳稳下行的八级石阶",
            "tagline_en": "Stop chasing passing clouds overhead—step onto the eight descending stones underfoot",
            "body": (
                "把《咏叹调》想象成一座两进院落：前院 A 段有 16 根柱子，后院 B 段也有 16 根柱子；每进院落都逛两遍（A1→A2→B1→B2），"
                "合起来就是 64 次柱影流转。最容易辨认的是前八根柱子：低音像一位沉稳的夜巡人，一步一阶往下走——"
                "G – F♯ – E – D – B – C – D – G（听起来就像“稳、落、沉、定——转身回家”）。无论右手在上面翻起多么眼花缭乱的浪花，"
                "这 32 根承重柱永远准时在原地托住整栋建筑。"
            ),
            "body_en": (
                "Picture the Aria as a two-courtyard palace: Courtyard A stands on 16 pillars, Courtyard B on another 16, "
                "and we walk through each courtyard twice (A1 → A2 → B1 → B2, 64 pillar-beats in full). The easiest landmark "
                "is the opening eight pillars, where the bass descends like stone steps into a garden—G–F♯–E–D–B–C–D–G "
                "('step, sink, settle, pause—turn and come home'). No matter how wildly the upper voices spin fireworks overhead, "
                "these 32 load-bearing columns arrive right on schedule beneath every single variation."
            ),
            "tryLabel": "点按下方第 1–8 号金柱，先让耳朵记住这段“下台阶再回家”的低音脚印",
            "tryLabel_en": "Tap Pillars 1–8 below to imprint the descending 'staircase-and-homecoming' bass footsteps in your ear",
        },
        {
            "id": "canon",
            "stepNum": 2,
            "title": "机关二 · 每逢三必有卡农：影子追逐与水中倒影",
            "title_en": "Key 2 · Every Third Step a Canon: Shadow-Chasing & Water Reflections",
            "tagline": "第 3、6、9、12、15……巴赫用九道逐步拉开的音程阶梯丈量宇宙",
            "tagline_en": "Vars. 3, 6, 9, 12, 15… Bach measures the cosmos with nine ever-widening intervals",
            "body": (
                "巴赫把 30 首变奏按“三首一组”排成十座三联画：每组第 1 首是性格鲜明的舞曲或小品，第 2 首是飞檐走壁的炫技曲，"
                "而每组第 3 首（第 3、6、9、12、15……变奏）必定是一首严丝合缝的“卡农”！什么是卡农？就像两个人在林间小径一前一后走："
                "在第 3 变奏（同度卡农）里，后出发的“影子”踩着领跑者完全相同的脚印追赶；到了第 12 与第 15 变奏（反向卡农），"
                "影子变成了湖面上的倒影——领跑者往低处叹息一步，倒影就往高空升起一步，分毫不差地镜像对称！"
            ),
            "body_en": (
                "Bach organizes all 30 variations into ten three-panel triptychs: Slot 1 is a vivid dance or character piece, "
                "Slot 2 a dazzling keyboard toccata, and every Slot 3 (Vars. 3, 6, 9, 12, 15…) is a strict canon! What is a canon? "
                "Imagine two walkers on a forest trail: in Var. 3 (Canon at the Unison), the follower steps into the leader's exact "
                "footprints a moment later; in Vars. 12 and 15 (Inverted Canons), the follower becomes a lake reflection—every step "
                "the leader takes downward, its mirror twin rises upward into the sky!"
            ),
            "tryLabel": "切换对比“同度追逐（第 3 变奏）”与“湖面倒影（第 15 变奏）”，看两条旋律线如何咬合",
            "tryLabel_en": "Toggle between 'Shadow Chase (Var. 3)' and 'Lake Reflection (Var. 15)' to watch the twin lines interlock",
        },
        {
            "id": "crossing",
            "stepNum": 3,
            "title": "机关三 · 双层羽管键琴折叠进一台斯坦威：任奫灿的高空杂技",
            "title_en": "Key 3 · Two Harpsichord Decks Folded into One Steinway: Yunchan Lim's High-Wire Act",
            "tagline": "原本上下分层的立交桥，到了现代钢琴上变成左右手百次穿花越位",
            "tagline_en": "A two-level Baroque overpass becomes a single-keyboard tightrope of flying hands",
            "body": (
                "巴赫当年为“双层键盘羽管键琴”（2 Clav.）写下许多变奏：两只手各占上下一层键盘，就算弹同一音区也像走上下两层立交桥，"
                "绝不会撞车。但在 2025 年卡内基音乐厅的舞台上，21 岁的任奫灿面前只有一排 88 键斯坦威琴键！两层立交桥被折叠进同一平面，"
                "左右手必须在毫厘之间互相跨越、腾挪、穿针引线（仅第 11 变奏就有 206 次声部交错！），还要仅凭指尖触键的深浅，"
                "在一排琴键上幻化出银笛、猎号与琉璃钟声三种截然不同的音色。"
            ),
            "body_en": (
                "Bach wrote many variations for a two-manual harpsichord ('2 Clav.'), where the two hands rode separate upper "
                "and lower keyboard decks like cars on a two-level overpass—sharing the exact same pitch zone without colliding. "
                "On stage at Carnegie Hall in April 2025, twenty-one-year-old Yunchan Lim faces a single 88-key Steinway! Folding "
                "that two-deck overpass onto one flat keyboard turns Toccatas like Vars. 5, 11, and 14 into breathtaking high-wire "
                "acrobatics (206 voice-crossings in Var. 11 alone!), demanding miracle-level touch differentiation so intersecting "
                "voices never blur."
            ),
            "tryLabel": "打开声部交错高亮，亲眼见证双手在同一音区穿梭而不乱一丝纹路",
            "tryLabel_en": "Turn on Voice-Crossing Glow to watch both hands weave through the exact same register without tangling",
        },
    ],
}


CHAPTERS_0_15 = {
    0: {
        "code": "Aria",
        "code_en": "Aria",
        "title": "咏叹调 · 三十二根黄金立柱的诞生",
        "title_en": "Aria · Birth of the Thirty-Two Golden Pillars",
        "subtitle": "萨拉班德舞曲 · G大调 · 3/4拍 · 双排键（2 Clav.）",
        "subtitle_en": "Sarabande · G major · 3/4 · Two Manuals (2 Clav.)",
        "category": "portal",
        "triad": 0,
        "canonInterval": None,
        "canonInverted": False,
        "keyMode": "G major",
        "manuals": "2 Clav.",
        "limHighlight": True,
        "noviceHook": (
            "前五秒请把耳朵分成两半：高处是一朵在烛光里缓缓舒展的金色花冠，脚下则是每三拍稳稳落定一步的八级石阶——"
            "整部八十分钟巨作的基因密码，此刻正安静地铺展在你面前。"
        ),
        "noviceHook_en": (
            "In the first five seconds, split your ear in two: high above, a golden floral garland unfurls by candlelight; "
            "deep below, calm footsteps descend one stone step per measure—planting the genetic code of the entire eighty-minute journey."
        ),
        "recipe": (
            "这首《咏叹调》最早出现在巴赫送给妻子安娜·玛格达莱娜的音乐笔记本中，体裁是庄重而略带呼吸停顿的法国“萨拉班德”三拍子舞曲"
            "（留意每小节第二拍那一下温柔的倚靠感）。巴赫在表面的花腔旋律之下，暗暗立起了前段 16 根、后段 16 根共 32 根和声立柱："
            "前 8 根从主音 G 一路级进滑落再回旋归家，第 9 至 16 根迈向明亮的属调 D 大调阳光庭院；后半程第 17 至 24 根悄悄拐入"
            "温润的 E 小调树荫，最后第 25 至 32 根以宽广的下行音阶稳稳收束回 G 大调家园。"
        ),
        "recipe_en": (
            "Originally copied into Anna Magdalena Bach's 1725 notebook, the Aria is a poised French Sarabande in 3/4 meter—"
            "listen for how the second beat gently leans and lingers like a drawn breath. Beneath the ornate soprano filigree, "
            "Bach erects 16 harmonic pillars in Part A and 16 in Part B: Pillars 1–8 step calmly down from G and arc homeward; "
            "Pillars 9–16 open a sunlit courtyard in D major; Pillars 17–24 wander into velvet E-minor shade; and Pillars 25–32 "
            "glide home on a long, serene bass descent back to G major."
        ),
        "limNote": (
            "在 2025 年 4 月 25 日卡内基音乐厅现场（全长 4 分 04 秒），任奫灿直到 0.9 秒才从屏息的寂静中落下第一颗 G5 高音，"
            "琴音清澈得像古瓷碗边缘泛起的微光。更迷人的是他在反复时的戏剧呼吸：57.4 秒进入 A2、173.5 秒进入 B2 时，"
            "他不仅让右手装饰音绽放出即兴歌唱般的细微弹性，还悄悄点亮左手内声部的叹息线条，仿佛同一间烛光长廊在第二次走过时被月光重新勾勒。"
        ),
        "limNote_en": (
            "Live at Carnegie Hall on April 25, 2025 (244.4s / 4:04), Yunchan Lim lets nearly a full second of hushed hall silence "
            "hang before floating the opening G5 at 0.9s like light off translucent porcelain. Listen to how he transforms the repeats: "
            "entering A2 at 57.4s and B2 at 173.5s, he breathes spontaneous vocal rubato into Bach's delicate ornaments while illuminating "
            "the inner tenor sighs, as if walking through the same candlelit gallery a second time under moonlight."
        ),
        "voicesMeta": [
            {
                "name": "高音咏叹花腔",
                "name_en": "Ornate Soprano Cantilena",
                "role": "悬浮于顶层的丝绸旋律，缀满颤音、倚音与温柔的呼吸转折",
                "role_en": "Floating silk melody crowned with luminous mordents, appoggiaturas, and vocal turns",
            },
            {
                "name": "中音叹息内声部",
                "name_en": "Sighing Inner Alto-Tenor",
                "role": "在每小节第二拍轻轻托起和声暖意，让三拍子萨拉班德产生心脏搏动般的起伏",
                "role_en": "Enters on beat two to cushion the harmony, giving the Sarabande its gentle heartbeat lean",
            },
            {
                "name": "黄金立柱主干线",
                "name_en": "Harmonic Pillar Line",
                "role": "一步一柱勾勒 G–F♯–E–D 下行石阶，串联起全曲 32 根承重坐标",
                "role_en": "Steps through the iconic G–F♯–E–D descent, tracing the 32 architectural coordinates",
            },
            {
                "name": "深层低音基座",
                "name_en": "Deep Sarabande Foundation",
                "role": "在关键终止式下潜至浑厚低音区（最低触及 D2），为整座圣殿锚定重力中心",
                "role_en": "Drops into resonant bass depths (down to D2) at cadences to anchor the cathedral's gravity",
            },
        ],
        "stages": [
            {
                "pass": "A1",
                "pillar": 1,
                "title": "初见 · 八级黄金石阶悄然铺展",
                "title_en": "First Encounter · Eight Golden Steps Unfurl",
                "desc": "高音从清亮的 G5 轻轻滑落，脚下低音稳稳踏出 G–F♯–E–D–B–C–D–G 八根承重立柱。",
                "desc_en": "Soprano floats down from a bell-pure G5 while the bass plants the iconic eight-pillar G–F♯–E–D–B–C–D–G descent.",
                "focus": "先盯住低音每秒一步的沉稳下行，别被高音花饰带跑",
                "focus_en": "Lock onto the calm descending bass footsteps underneath the floral melody",
            },
            {
                "pass": "A1",
                "pillar": 9,
                "title": "前院转折 · 推开 D 大调的阳光侧窗",
                "title_en": "Courtyard Turn · Opening the Sunlit D-Major Window",
                "desc": "和声从静谧的主调转向更敞亮的属调 D 大调，旋律向上攀升后温柔停靠在半途驿站。",
                "desc_en": "Harmony brightens toward D major as the melody arches upward and settles onto the halfway cadence.",
                "focus": "感受第 15–16 柱音乐豁然开朗、稳稳落座的句号感",
                "focus_en": "Feel the sunny opening-out and poised landing at Pillars 15–16",
            },
            {
                "pass": "A2",
                "pillar": 1,
                "title": "前院重游 · 月光下的内声部私语",
                "title_en": "A-Repeat · Inner Voices Whisper by Moonlight",
                "desc": "57.4 秒回到第 1 柱，任奫灿把表层旋律放得更轻柔，让中间两层和声像丝绒一样浮现出来。",
                "desc_en": "Returning to Pillar 1 at 57.4s, Lim softens the top line so the velvet inner voices glow from within.",
                "focus": "听高音与低音“夹心层”里第二拍轻轻叹气的内声部",
                "focus_en": "Listen into the 'middle sandwich' for the gentle beat-two inner sighs",
            },
            {
                "pass": "A2",
                "pillar": 9,
                "title": "前院收束 · 装饰音如露珠滚落荷叶",
                "title_en": "Closing Courtyard A · Ornaments Roll Like Dewdrops",
                "desc": "细密的颤音毫不机械，像歌者换气后的自然颤动，把前院推向静谧的悬停。",
                "desc_en": "Delicate trills shimmer like a singer's natural vibrato, bringing the first half to a hushed poise.",
                "focus": "留意第 14–16 柱指尖在颤音尾端那丝毫不着急的呼吸留白",
                "focus_en": "Notice the unhurried breathing space at the tail of the cadential trills",
            },
            {
                "pass": "B1",
                "pillar": 17,
                "title": "步入后院 · 拐进 E 小调的幽深树荫",
                "title_en": "Entering Courtyard B · Into Velvet E-Minor Shade",
                "desc": "113.9 秒跨过中轴线，色彩渐渐染上一抹温柔的微愁，第 21–24 柱在 E 小调里发出全曲最动人的沉思。",
                "desc_en": "Crossing the midpoint at 113.9s, colors deepen toward tender E-minor shadow around Pillars 21–24.",
                "focus": "捕捉第 21 柱起突然变暗、变暖的小调光影变化",
                "focus_en": "Catch the sudden shift into warm, shadowed minor light from Pillar 21",
            },
            {
                "pass": "B1",
                "pillar": 25,
                "title": "归途长阶 · 攀上最高峰后从容返航",
                "title_en": "Homeward Staircase · Cresting the Peak and Gliding Home",
                "desc": "高音旋律向上舒展到至高点，随即乘着连绵的十六分音符流水，一步步回到 G 大调怀抱。",
                "desc_en": "The soprano crests peacefully, then rides a flowing stream of sixteenths smoothly back to G major.",
                "focus": "听旋律像一片羽毛顺着晚风盘旋落回地面",
                "focus_en": "Follow the melody drifting down like a feather settling to earth",
            },
            {
                "pass": "B2",
                "pillar": 17,
                "title": "终章回望 · 告别安宁，准备启程",
                "title_en": "Final Repeat · A Last Quiet Gaze Before the Voyage",
                "desc": "173.5 秒最后一次踏入后院，任奫灿把速度放得更加悠远深邃，仿佛在远航前凝视故乡的灯火。",
                "desc_en": "Entering B2 at 173.5s, Lim broadens the pulse into timeless stillness—one last look at home harbor before setting sail.",
                "focus": "感受小调段落里比第一遍更深沉的歌唱张力",
                "focus_en": "Savor the deeper vocal intensity in the E-minor shadow on this second pass",
            },
            {
                "pass": "B2",
                "pillar": 25,
                "title": "余音入定 · 悬在空气里的最后一缕烛烟",
                "title_en": "Vanishing Cadence · Candle Smoke Suspended in Air",
                "desc": "最后八根金柱缓缓收拢，终结和弦在卡内基大厅里静静消融——下一秒，第一变奏的欢腾即将破门而入！",
                "desc_en": "The final eight pillars gather gently home; the last G-major chord dissolves into expectant Carnegie Hall air.",
                "focus": "屏住呼吸听第 32 柱余音彻底归零的那一秒悬念",
                "focus_en": "Hold your breath as Pillar 32's resonance fades before Variation 1 bursts in",
            },
        ],
        "cues": [
            {"pass": "A1", "pillar": 1, "label": "第一滴瓷光 G5 与首根金柱", "label_en": "Porcelain G5 & Pillar 1"},
            {"pass": "A1", "pillar": 13, "label": "迈向 D 大调阳光庭院", "label_en": "Sunlit D-Major Cadence"},
            {"pass": "A2", "pillar": 1, "label": "A2 反复：点亮丝绒内声部", "label_en": "A2 Repeat: Velvet Inner Voices"},
            {"pass": "B1", "pillar": 21, "label": "E 小调树荫下的温柔叹息", "label_en": "Tender E-Minor Shadow"},
            {"pass": "B2", "pillar": 29, "label": "归航长阶与烛光余韵", "label_en": "Homeward Descent & Hushed Close"},
        ],
    },

    1: {
        "code": "Var. 1",
        "code_en": "Var. 1",
        "title": "第一变奏 · 破门而出的波兰宫廷盛装舞",
        "title_en": "Variation 1 · Sunburst Polonaise Bursting Through the Doors",
        "subtitle": "波兰舞曲风 · G大调 · 3/4拍 · 单排键（1 Clav.）",
        "subtitle_en": "Polonaise · G major · 3/4 · Single Manual (1 Clav.)",
        "category": "character",
        "triad": 1,
        "canonInterval": None,
        "canonInverted": False,
        "keyMode": "G major",
        "manuals": "1 Clav.",
        "limHighlight": True,
        "noviceHook": (
            "刚刚还在烛光里冥想，大门突然“砰”地敞开！听左手那种“咚—哒哒—咚”一脚深一脚浅的欢快跳跃，"
            "就像盛装舞者踩着马靴踏进洒满晨光的广场。"
        ),
        "noviceHook_en": (
            "Meditation shatters as palace doors swing wide! Listen to the left hand's buoyant 'boom–da-da–boom' stride—"
            "dancers in polished boots leaping into a sunlit square."
        ),
        "recipe": (
            "作为第一组三联画的开篇“性格小品”，巴赫只用区区两个声部就掀起了满堂欢腾：右手甩出神采飞扬的十六分音符彩带，"
            "左手则把原本平缓下行的 32 根低音金柱改造成神气活现的波兰舞曲（Polonaise）节奏。仔细听第 13 至 16 柱以及后半段："
            "左右手突然互换角色，连翻 24 次交叉越位，像两位舞伴在旋转中频频击掌换位！"
        ),
        "recipe_en": (
            "Opening Triad 1 as a vivid character dance, Bach ignites festive energy with just two voices: the right hand unfurls "
            "gleaming sixteenth-note ribbons while the left transforms our 32 calm bass pillars into swaggering Polonaise leaps. "
            "Listen closely around Pillars 13–16 and throughout Part B: the hands trade roles and leap across one another 24 times "
            "like dance partners clapping and spinning past each other!"
        ),
        "limNote": (
            "任奫灿以 1 分 51 秒（110.9 秒）弹出令人嘴角上扬的青春朝气！他没有把重音砸得笨重，而是用极富弹性的指尖颗粒感让左手大跳像香槟气泡一样往上冒；"
            "到了 26.2 秒的 A2 反复与 80.9 秒的 B2 反复，他故意在双手交错的高低呼应里制造俏皮的明暗对比，活脱脱一出微缩喜剧。"
        ),
        "limNote_en": (
            "Clocking a sparkling 1:51 (110.9s), Yunchan Lim infuses the Polonaise with irresistible youthful bounce. Rather than "
            "stamping heavy accents, his crisp staccato makes the left-hand leaps fizz like champagne bubbles; in the A2 (26.2s) "
            "and B2 (80.9s) repeats, he plays up cheeky dynamic repartee whenever the two hands trade registers."
        ),
        "voicesMeta": [
            {
                "name": "右手飞扬彩带",
                "name_en": "Right-Hand Polonaise Ribbon",
                "role": "清脆流转的十六分音符华彩，时而化作号角般的短促回声与左手对答",
                "role_en": "Crisp sixteenth-note flourishes trading bright horn-call echoes with the bass",
            },
            {
                "name": "左手跳跃金柱",
                "name_en": "Leaping Ground-Bass Stride",
                "role": "把 32 根承重柱变成弹性十足的波兰舞步，并在中段大胆越过右手翻上高空",
                "role_en": "Turns the 32 pillars into buoyant Polonaise strides, vaulting over the right hand mid-flight",
            },
        ],
        "stages": [
            {
                "pass": "A1",
                "pillar": 1,
                "title": "晨光登场 · 金柱化作欢跃舞靴",
                "title_en": "Sunburst Entrance · Pillars Put On Dancing Boots",
                "desc": "第 1–4 柱的 G–F♯–E–D 还在脚下，却变成了神采奕奕的切分跳跃，瞬间唤醒全场耳朵。",
                "desc_en": "Pillars 1–4 (G–F♯–E–D) are still right underfoot, now transformed into jubilant syncopated leaps.",
                "focus": "听左手重拍落点后紧跟着往上弹起的那一下轻盈跳音",
                "focus_en": "Catch the springy upward rebound right after each downbeat bass note",
            },
            {
                "pass": "A2",
                "pillar": 1,
                "title": "前院再舞 · 俏皮的回声问答",
                "title_en": "A-Repeat · Playful Echo Repartee",
                "desc": "26.2 秒重返起点，任奫灿把句尾双手互相模仿的短促音型弹得像一唱一和的眨眼玩笑。",
                "desc_en": "At 26.2s Lim highlights the witty call-and-response echoes near the end of Courtyard A.",
                "focus": "留意第 13–16 柱双手一高一低像打乒乓球一样互抛短句",
                "focus_en": "Listen at Pillars 13–16 as the two hands volley short motifs like ping-pong",
            },
            {
                "pass": "B1",
                "pillar": 17,
                "title": "换位旋舞 · 左右手首次空中交叉",
                "title_en": "Crossing Spins · Hands Leap Across Mid-Dance",
                "desc": "53.3 秒进入后半程，原本跑动的流水交给左手，右手反而跳起舞步，双手在琴键中央穿梭交错。",
                "desc_en": "Entering B1 at 53.3s, the left hand seizes the running stream while the right vaults above and below it.",
                "focus": "听低音区突然涌起连绵水波，而清脆跳音从头顶飞越过去",
                "focus_en": "Hear continuous ripples surge in the bass while crisp staccatos leap overhead",
            },
            {
                "pass": "B2",
                "pillar": 17,
                "title": "盛装收尾 · 一气呵成的华丽谢幕",
                "title_en": "Grand Finale · Sparkling Curtain Bow",
                "desc": "80.9 秒开启最后一遍冲刺，颗粒分明的跑动一路推向干净利落的同度收束。",
                "desc_en": "Launching B2 at 80.9s, crystalline passagework hurtles joyfully into a razor-clean unison bow.",
                "focus": "最后四根柱子双手汇成一股洪流稳稳刹住的爽快感",
                "focus_en": "Relish the exhilarating unison convergence across the final four pillars",
            },
        ],
        "cues": [
            {"pass": "A1", "pillar": 1, "label": "波兰舞靴破门而出", "label_en": "Buoyant Polonaise Leap"},
            {"pass": "A1", "pillar": 13, "label": "双手乒乓对答与初次越位", "label_en": "Ping-Pong Echoes & Hand Crossing"},
            {"pass": "B1", "pillar": 17, "label": "角色互换：左手掀起滚滚流水", "label_en": "Role Swap: Left-Hand Torrent"},
            {"pass": "B2", "pillar": 29, "label": "疾风冲刺与清脆谢幕", "label_en": "Sparkling Final Sprint"},
        ],
    },

    2: {
        "code": "Var. 2",
        "code_en": "Var. 2",
        "title": "第二变奏 · 阳光庭院里的三重奏鸣曲对话",
        "title_en": "Variation 2 · Sunlit Trio-Sonata Conversation",
        "subtitle": "巴洛克三重奏鸣曲 · G大调 · 2/4拍 · 单排键（1 Clav.）",
        "subtitle_en": "Baroque Trio Sonata · G major · 2/4 · Single Manual (1 Clav.)",
        "category": "virtuoso",
        "triad": 1,
        "canonInterval": None,
        "canonInverted": False,
        "keyMode": "G major",
        "manuals": "1 Clav.",
        "limHighlight": False,
        "noviceHook": (
            "闭上眼，舞台上仿佛站着三位室内乐手：大提琴在底下迈着均匀的小碎步，两把小提琴在头顶一前一后互相接话、打趣，"
            "温柔得像午后树影里的闲聊。"
        ),
        "noviceHook_en": (
            "Close your eyes and picture three chamber players in a sunlit courtyard: a cello strolls steadily below while "
            "two violins overhead finish each other's sentences in warm, affectionate banter."
        ),
        "recipe": (
            "虽然处在第一组三联画的第 2 格（器乐织体格），巴赫却没有急着炫耀狂飙手速，而是把意大利“三重奏鸣曲”（两件高音乐器加通奏低音）"
            "浓缩进十根手指里。一只右手要同时分饰两把性格独立的小提琴：一把刚拉出带颤音的小跳跃，另一把立刻在两拍后模仿回应，"
            "为下一首真正的严格卡农悄悄做耳朵热身！"
        ),
        "recipe_en": (
            "Occupying Slot 2 of Triad 1, Bach holds back raw pyrotechnics to distill an Italian Trio Sonata—two solo violins "
            "over basso continuo—into ten fingers. One right hand must voice two independent singing lines that playfully imitate "
            "each other's trilled motifs, gently warming up the listener's ear for the strict canon waiting next door in Variation 3!"
        ),
        "limNote": (
            "在这段仅 1 分 28 秒（88.1 秒）的精致小品中，任奫灿展现出惊人的“单手分身术”：他给高声部涂上清亮银光，给中声部染上温润木质音色，"
            "两条旋律即使发生 20 次交错也绝不糊成一团；41.6 秒进入 B1 后，切分悬留音被他拉出弦乐揉弦般的连绵暖意。"
        ),
        "limNote_en": (
            "Across a succinct 1:28 (88.1s), Yunchan Lim performs a quiet miracle of one-hand polyphony: coloring the top voice "
            "silvery-bright and its twin warm and woody so their 20 crossings remain crystal clear. Entering B1 at 41.6s, his "
            "tied suspensions sing like bowed strings leaning affectionately into one another."
        ),
        "voicesMeta": [
            {
                "name": "第一小提琴声部",
                "name_en": "First Violin Voice",
                "role": "在第 3 柱高调接话登场（G5），在高音区闪烁银色颤音与优雅连线",
                "role_en": "Enters brightly on G5 in bar 3, gleaming aloft with silver mordents and lyric suspensions",
            },
            {
                "name": "第二小提琴声部",
                "name_en": "Second Violin Voice",
                "role": "开篇率先唱出亲切主题（B4），与高声部缠绵追逐、互换高低位置",
                "role_en": "Opens the conversation warmly on B4, intertwining and trading places with Violin I",
            },
            {
                "name": "漫步大提琴低音",
                "name_en": "Walking Cello Ground Bass",
                "role": "以均匀不断的八分音符漫步托底，像钟表齿轮般稳稳推进 32 根金柱",
                "role_en": "Strolls in steady eighth-note footsteps, propelling the 32 harmonic pillars forward",
            },
        ],
        "stages": [
            {
                "pass": "A1",
                "pillar": 1,
                "title": "庭院初语 · 两把小提琴一唱一随",
                "title_en": "Courtyard Greeting · Two Violins Trade Smiles",
                "desc": "中声部先抛出轻巧主题，第 3 柱高声部立刻从高处接过话头，下方低音稳步伴行。",
                "desc_en": "The middle voice tosses out a graceful motif; at Pillar 3 the upper voice catches it higher up over the walking bass.",
                "focus": "数到第 3 柱，听高处第二位“歌者”清亮接话的那一瞬间",
                "focus_en": "Listen at Pillar 3 for the bright upper 'second singer' joining the chat",
            },
            {
                "pass": "A2",
                "pillar": 1,
                "title": "默契升温 · 缠绕上升的连绵叹息",
                "title_en": "A-Repeat · Intertwining Suspensions",
                "desc": "20.9 秒重返前院，任奫灿把两个高声部交替拉长的挂留音弹得如丝绸交织。",
                "desc_en": "Repeating A at 20.9s, Lim shapes the overlapping tied notes like two silk ribbons braiding upward.",
                "focus": "听两条高音旋律一前一后“你停我走、我停你走”的呼吸感",
                "focus_en": "Follow the 'you-hold-while-I-step' relay between the two upper lines",
            },
            {
                "pass": "B1",
                "pillar": 17,
                "title": "树影漫步 · 小调微澜里的温情对话",
                "title_en": "Shaded Stroll · Tender Minor-Key Dialogue",
                "desc": "41.6 秒步入后半程，大提琴低音偶尔也忍不住加入模仿，三人行的对话愈发亲密。",
                "desc_en": "At 41.6s the walking bass joins the motivic conversation as harmonies dip briefly into gentle minor shade.",
                "focus": "注意低音不再只是伴奏，也悄悄学会了上面的短促动机",
                "focus_en": "Notice the bass picking up the upper voices' conversational motif",
            },
            {
                "pass": "B2",
                "pillar": 17,
                "title": "余韵不止 · 没有句号的开放式收束",
                "title_en": "Unhurried Close · Flowing Right to the Edge",
                "desc": "62.9 秒最后一遍漫步，音乐一直流淌到最后一拍才轻巧收住，把耳朵自然引向第一首卡农。",
                "desc_en": "Beginning B2 at 62.9s, the chamber dialogue flows seamlessly to the very final beat, priming our ears for Canon 1.",
                "focus": "听最后一根柱子像一句话说到尾字轻轻挑眉收住的韵味",
                "focus_en": "Catch the poised, unforced landing right at Pillar 32",
            },
        ],
        "cues": [
            {"pass": "A1", "pillar": 1, "label": "漫步低音与首把小提琴开腔", "label_en": "Walking Bass & First Theme"},
            {"pass": "A1", "pillar": 3, "label": "高声部接话：三重奏正式成型", "label_en": "Upper Voice Answers: Full Trio"},
            {"pass": "B1", "pillar": 17, "label": "后院漫步：三声部亲密交谈", "label_en": "Courtyard B: Three-Way Banter"},
            {"pass": "B2", "pillar": 25, "label": "丝滑盘旋归家", "label_en": "Silky Homeward Glide"},
        ],
    },

    3: {
        "code": "Var. 3",
        "code_en": "Var. 3",
        "title": "第三变奏 · 同度卡农：踩着同一串脚印的影子游戏",
        "title_en": "Variation 3 · Canon at the Unison: Two Walkers, One Exact Trail",
        "subtitle": "同度卡农 · G大调 · 12/8拍 · 单排键（1 Clav.）",
        "subtitle_en": "Canone all'Unisono · G major · 12/8 · Single Manual (1 Clav.)",
        "category": "canon",
        "triad": 1,
        "canonInterval": 1,
        "canonInverted": False,
        "keyMode": "G major",
        "manuals": "1 Clav.",
        "limHighlight": False,
        "noviceHook": (
            "全曲第一座卡农纪念碑来了！听第一小节唱出的摇曳牧歌，仅仅三秒后，一个一模一样的“孪生影子”从完全相同的音高出发，"
            "分毫不差地追着它跑完整个乐章！"
        ),
        "noviceHook_en": (
            "Behold the first Canon monument! Hear the swaying pastoral tune in bar 1—then three seconds later, an identical "
            "twin sets off from the exact same note, chasing every twist and turn to the very end!"
        ),
        "recipe": (
            "每逢“三的倍数”，巴赫就立起一座卡农里程碑。第 3 变奏是起点——“同度卡农”（音程距离 = 1 度，即零高度差）："
            "领唱声部（Dux）从中央偏高的 B4 出发，追随声部（Comes）隔一小节也从同一个 B4 出发，每一个音符都原样复刻！"
            "因为两人站在同一层楼面追逐，它们在全曲中足足互相穿过对方 116 次，底下则由摇篮船般的 12/8 拍低音稳稳托举。"
        ),
        "recipe_en": (
            "Every third variation raises a canonic milestone, beginning here at Interval 1—the Unison! The Leader (Dux) sets "
            "off on B4, and one bar later the Follower (Comes) launches from that exact same B4, duplicating every single pitch "
            "and rhythm. Because both voices inhabit the identical register, they weave through each other 116 times over a "
            "gently rocking 12/8 pastoral ground bass."
        ),
        "limNote": (
            "同一只手要在完全相同的音区弹出两条重叠 116 次的同度旋律，稍不留神就会糊成一锅粥。任奫灿在 2 分 02 秒（122.4 秒）的演绎中，"
            "赋予领唱者清朗的阳光弧线，给晚一步的追随者披上柔和的回声光泽；59.9 秒进入 B1 后，船歌般的律动温暖得让人想随音乐轻轻摇晃。"
        ),
        "limNote_en": (
            "Projecting two unison voices that cross 116 times in the exact same pitch zone on a single Steinway is a supreme "
            "voicing test. Across a warm, swaying 2:02 (122.4s), Yunchan Lim gives the Leader sunlit forward poise and shades "
            "the Follower like a mellow echo; entering B1 at 60.0s, the 12/8 pastoral lilt cradles the ear effortlessly."
        ),
        "voicesMeta": [
            {
                "name": "卡农领唱声部（Dux）",
                "name_en": "Canon Leader (Dux)",
                "role": "从第 1 柱率先唱响（B4），为整场追逐铺设每一道起伏与回旋轨迹",
                "role_en": "Sets off at Pillar 1 on B4, blazing every melodic curve of the trail",
            },
            {
                "name": "同度追随影子（Comes）",
                "name_en": "Unison Follower (Comes)",
                "role": "晚一柱从完全相同的 B4 出发，与领唱者穿花交错 116 次却步步紧随",
                "role_en": "Launches one bar later on the exact same B4, crossing the Leader 116 times in faithful pursuit",
            },
            {
                "name": "田园摇篮低音",
                "name_en": "Pastoral 12/8 Ground Bass",
                "role": "以舒缓的三连音船歌律动铺展 32 根金柱，稳稳托住上方双生旋律",
                "role_en": "Cradles the twin canon voices above a gently rolling 12/8 pastoral bass line",
            },
        ],
        "stages": [
            {
                "pass": "A1",
                "pillar": 1,
                "title": "影子启程 · 同一颗 B4 音符的两次出发",
                "title_en": "Shadow Launch · Twice From the Exact Same B4",
                "desc": "第 1 柱领唱者刚唱出悠扬牧歌，第 2 柱孪生影子就在同一音高准时踩进它的脚印。",
                "desc_en": "At Pillar 1 the Leader sings out on B4; at Pillar 2 its twin steps onto that exact same B4 right behind it.",
                "focus": "死死盯住开头前两小节：听第二小节如何一模一样重播第一小节！",
                "focus_en": "Focus on bars 1 and 2: hear bar 2 replay bar 1 note-for-note from the identical pitch!",
            },
            {
                "pass": "A2",
                "pillar": 1,
                "title": "穿花共舞 · 同一音区里的金色编织",
                "title_en": "A-Repeat · Golden Braiding in One Register",
                "desc": "29.6 秒重返起点，这次试着不追领跑者，专门去抓晚一步跟上来的“回声影子”。",
                "desc_en": "At 29.6s try flipping your ear: ignore the Leader and follow the one-bar-late Shadow all the way!",
                "focus": "感受两条旋律频繁上下翻花却始终和谐得像一个人",
                "focus_en": "Marvel at how two overlapping lines swap top position seamlessly",
            },
            {
                "pass": "B1",
                "pillar": 17,
                "title": "田园暮色 · 摇曳在小调微风中的双人舞",
                "title_en": "Pastoral Dusk · Twin Voices in Minor Breeze",
                "desc": "60.0 秒步入后院，旋律线条拉得更修长，在 E 小调段落化作温柔缠绵的船歌。",
                "desc_en": "Entering B1 at 60.0s, longer-breathed phrases drift into warm minor shade like twin gondolas at dusk.",
                "focus": "听底下 12/8 低音像湖水轻拍船舷一样平稳起伏",
                "focus_en": "Feel the steady 12/8 bass lapping gently beneath the twin voices",
            },
            {
                "pass": "B2",
                "pillar": 17,
                "title": "归巢合拢 · 影子在终点追上本尊",
                "title_en": "Homecoming · Shadow Catches Its Twin at Last",
                "desc": "89.6 秒开启最后一遍巡礼，直到第 32 柱最后一刻，追赶了一整首的影子终于与领唱者握手言欢。",
                "desc_en": "From 89.6s to the close, the relentless pursuit resolves gently as Leader and Shadow finally clasp hands at Pillar 32.",
                "focus": "听结尾最后一小节两道影子严丝合缝叠入终结和弦",
                "focus_en": "Hear the twin lines converge peacefully into the final G-major chord",
            },
        ],
        "cues": [
            {"pass": "A1", "pillar": 1, "label": "领唱出发，3秒后同度影子紧随", "label_en": "Leader & Unison Shadow Entry"},
            {"pass": "A2", "pillar": 1, "label": "A2 反复：换耳朵专抓“影子声部”", "label_en": "A2 Repeat: Follow the Shadow"},
            {"pass": "B1", "pillar": 21, "label": "小调田园船歌的温柔缠绵", "label_en": "Warm Minor Pastoral Cradle"},
            {"pass": "B2", "pillar": 31, "label": "影子与本尊在终点重逢", "label_en": "Twin Voices Converge Home"},
        ],
    },

    4: {
        "code": "Var. 4",
        "code_en": "Var. 4",
        "title": "第四变奏 · 森林木屐舞：一分钟的四声部旋转木马",
        "title_en": "Variation 4 · Passepied Carousel: A One-Minute Four-Voice Whirlwind",
        "subtitle": "帕斯皮耶舞曲 · G大调 · 3/8拍 · 单排键（1 Clav.）",
        "subtitle_en": "Passepied · G major · 3/8 · Single Manual (1 Clav.)",
        "category": "character",
        "triad": 2,
        "canonInterval": None,
        "canonInverted": False,
        "keyMode": "G major",
        "manuals": "1 Clav.",
        "limHighlight": False,
        "noviceHook": (
            "全曲最短小精悍的快乐旋风（仅 65 秒）！四个声部像四个穿着木屐的小精灵，拿着同一个“哒-哒-咚”三音口令，"
            "从高到低排着队一个接一个蹦进舞池！"
        ),
        "noviceHook_en": (
            "A sixty-five-second whirlwind of rustic joy! Four voices leap onto the dance floor one after another like sprites "
            "in wooden clogs, tossing the same snappy three-note password from top to bottom!"
        ),
        "recipe": (
            "第二组三联画由法国布列塔尼民间源流的快三拍“帕斯皮耶舞曲”（Passepied，3/8 拍）热闹开席。巴赫把全曲写成极其紧凑的四声部积木："
            "高音先抛出棱角分明的四度/五度跳跃口令，中音、次中音紧随其后层层接力，而且四层声部各自守住自己的楼层（全曲 0 次声部交叉！），"
            "在咬合处撞出胡椒粒般辛辣又爽脆的挂留摩擦音。"
        ),
        "recipe_en": (
            "Triad 2 bursts open with a brisk French Passepied in 3/8 meter. Bach builds tight four-voice Lego blocks: soprano "
            "hurls a crisp leaping motif on the upbeat, alto and tenor pile in right behind, and all four voices stay strictly "
            "in their own lanes (zero voice crossings!) while sparking tangy, peppery harmonic clashes on strong beats."
        ),
        "limNote": (
            "任奫灿只用 1 分 05 秒（65.2 秒）就让这架旋转木马飞驰而过！他的触键干脆得像折断嫩树枝，却在 16.1 秒 A2 与 47.8 秒 B2 反复时，"
            "把高潮处刺耳又迷人的不协和重音轻轻点亮，赋予巴洛克宫廷舞一股鲜活的乡间野趣。"
        ),
        "limNote_en": (
            "Whipping through in a exhilarating 1:05 (65.2s), Yunchan Lim gives every upbeat leap rustic snap and electricity. "
            "On the A2 (16.1s) and B2 (47.8s) repeats, he leans deliciously into Bach's spicy strong-beat dissonances, turning "
            "courtly counterpoint into a exuberant village festival."
        ),
        "voicesMeta": [
            {
                "name": "高音领舞木屐",
                "name_en": "Soprano Passepied Sprite",
                "role": "弱拍率先跃起（B4–G4–D5），抛出贯穿全曲的清脆三音跳跃口令",
                "role_en": "Leaps in on the upbeat (B4–G4–D5) with the snappy motif that drives every bar",
            },
            {
                "name": "中音接力舞伴",
                "name_en": "Alto Relay Partner",
                "role": "紧随高音之后应声跳入，在强拍上制造辛辣欢快的和声碰撞",
                "role_en": "Jumps in right behind the soprano, sparking tangy strong-beat harmonic rubs",
            },
            {
                "name": "次中音回旋层",
                "name_en": "Tenor Echo Layer",
                "role": "填满中低音区的跳跃接力，让四层积木严丝合缝咬合转动",
                "role_en": "Completes the inner-voice relay so the four-part dance mechanism whirs tightly",
            },
            {
                "name": "帕斯皮耶踏步金柱",
                "name_en": "Passepied Stamping Bass",
                "role": "先以长音稳踏金柱，随后也按捺不住跟着跳起同款三音舞步",
                "role_en": "Stamps the opening pillars firmly before joining the contagious leaping motif itself",
            },
        ],
        "stages": [
            {
                "pass": "A1",
                "pillar": 1,
                "title": "木屐连跳 · 从高到低依次点火",
                "title_en": "Domino Ignition · Top-to-Bottom Leapfrog",
                "desc": "短短四秒内，高音、中音、次中音踩着同一个跳跃口令像多米诺骨牌一样噼啪点亮。",
                "desc_en": "Within four seconds, soprano, alto, and tenor pop in like dominoes over the stamping ground bass.",
                "focus": "听开头像爆米花一样从高往低连炸三次的同款跳跃节奏",
                "focus_en": "Catch the three cascading entries popping downward from treble to tenor",
            },
            {
                "pass": "A2",
                "pillar": 1,
                "title": "辛辣重拍 · 胡椒粒般的和声小摩擦",
                "title_en": "A-Repeat · Peppery Strong-Beat Sparks",
                "desc": "16.1 秒旋风重来，留意第 9–14 柱强拍上故意“撞”在一起再化开的酸爽音响。",
                "desc_en": "Spinning back at 16.1s, savor the crunchy strong-beat suspensions biting and resolving around Pillars 9–14.",
                "focus": "听第 11–13 柱那种微微酸涩又瞬间释然的咬合感",
                "focus_en": "Relish the tart, witty dissonance-and-release snaps mid-phrase",
            },
            {
                "pass": "B1",
                "pillar": 17,
                "title": "反向飞扑 · 口令倒转向上冲刺",
                "title_en": "B-Section Flip · Upward-Vaulting Replies",
                "desc": "32.1 秒跨入后院，跳跃动机纷纷倒转方向朝上猛蹿，舞池热度再升一级。",
                "desc_en": "At 32.1s the leaping figures flip direction and vault upward through darker minor harmonies.",
                "focus": "感受舞步从“往下踩”变成“往上挑”的轻盈失重感",
                "focus_en": "Feel the dance steps flip from downward stamps to upward vaults",
            },
            {
                "pass": "B2",
                "pillar": 17,
                "title": "戛然而止 · 一秒不拖泥带水的收刀",
                "title_en": "Clean Cut · Breathless Final Snap",
                "desc": "47.8 秒最后半圈飞驰，音乐在最高兴头上利落收住，为第 5 变奏的闪电风暴让出跑道！",
                "desc_en": "Racing from 47.8s to 1:05, the dance snaps shut on a dime—clearing the runway for Variation 5's lightning bolt!",
                "focus": "听结尾毫不减速、一锤定音的俏皮休止",
                "focus_en": "Enjoy the sudden, razor-sharp final cadence with zero slowdown",
            },
        ],
        "cues": [
            {"pass": "A1", "pillar": 1, "label": "三层木屐多米诺连跳登场", "label_en": "Cascading Passepied Entries"},
            {"pass": "A2", "pillar": 11, "label": "胡椒粒般酸爽的强拍碰撞", "label_en": "Spicy Strong-Beat Suspensions"},
            {"pass": "B1", "pillar": 17, "label": "后院起飞：舞步倒转向上挑", "label_en": "B1 Flip: Upward-Leaping Motifs"},
            {"pass": "B2", "pillar": 29, "label": "旋风收尾，一秒刹停", "label_en": "Whirlwind Snap Finish"},
        ],
    },

    5: {
        "code": "Var. 5",
        "code_en": "Var. 5",
        "title": "第五变奏 · 闪电穿花手：单排琴键上的百次高空越位",
        "title_en": "Variation 5 · Lightning Cross-Hands: High-Wire Acrobatics Across Eighty-Eight Keys",
        "subtitle": "双手交叉托卡塔 · G大调 · 3/4拍 · 单排或双排键（1 ô vero 2 Clav.）",
        "subtitle_en": "Cross-Hand Toccata · G major · 3/4 · 1 or 2 Manuals (1 ô vero 2 Clav.)",
        "category": "virtuoso",
        "triad": 2,
        "canonInterval": None,
        "canonInverted": False,
        "keyMode": "G major",
        "manuals": "1 ô vero 2 Clav.",
        "limHighlight": True,
        "noviceHook": (
            "系好安全带！全曲第一场真正的炫技风暴来了：一只手在琴键中央卷起疾风骤雨的音阶漩涡，"
            "另一只手像燕子点水一样，从它头顶飞过去踩高音、下一秒又钻到它肚子底下踩低音！"
        ),
        "noviceHook_en": (
            "Fasten your seatbelt for the first full-throttle keyboard storm! One hand spins a whirlwind ribbon down the middle "
            "while the other vaults over and dives under it like a swallow skimming both treetops and water!"
        ),
        "recipe": (
            "这是整部《哥德堡》第一首标明“单排或双排键”（1 ô vero 2 Clav.）的炫技变奏。巴赫吸收了斯卡拉蒂那令人目眩的“双手大跨越”特技："
            "两层声部在短短 32 根柱子里发生高达 146 次交叉！前半程通常是右手拉出奔流不息的十六分音符丝带，左手横跨三个八度上下飞跃，"
            "在最高音尖叫一声又立刻砸回最低音金柱；到了后半程，两只手干脆互换剧本，轮流走钢丝！"
        ),
        "recipe_en": (
            "The first variation marked '1 ô vero 2 Clav.', Variation 5 unleashes Scarlatti-like cross-hand fireworks with "
            "146 voice crossings! One hand spins an unbroken ribbon of racing sixteenths down the center of the keyboard while "
            "the other vaults three octaves back and forth—pinging bell-bright high notes above and grounding bass pillars below—"
            "before the two hands swap daredevil roles in Part B!"
        ),
        "limNote": (
            "78.2 秒（1 分 18 秒）！任奫灿在卡内基现场弹出令人屏息的极限速度与零失误准度，全场观众几乎能听见指尖划破空气的电流声。"
            "最绝的是 17.4 秒 A2 与 54.2 秒 B2 反复时，他让飞跃过顶的高音颗颗如银铃炸响，中间奔跑的十六分音符却像丝绸一样贴键滑行，"
            "快如闪电却没有半点燥热。"
        ),
        "limNote_en": (
            "Seventy-eight breathless seconds (78.2s / 1:18)! Live at Carnegie Hall, Yunchan Lim unleashes electrifying velocity "
            "with diamond-cut aim. Notice on the A2 (17.4s) and B2 (54.2s) repeats how every cross-hand leap rings out like a "
            "struck silver bell high overhead while the racing central ribbon purrs beneath it without a trace of harshness."
        ),
        "voicesMeta": [
            {
                "name": "疾风旋涡丝带",
                "name_en": "Whirlwind Sixteenth Ribbon",
                "role": "盘踞键盘中轴线高速旋转的连续音流，如陀螺般一刻不停提供推进力",
                "role_en": "Spins an unstoppable stream of rapid sixteenths through the middle of the keyboard",
            },
            {
                "name": "燕子穿云飞跃手",
                "name_en": "Vaulting Cross-Hand Acrobat",
                "role": "横跨数个八度上下翻飞（146 次越位），同时点亮云端银铃与地底金柱",
                "role_en": "Leaps wildly over and under the ribbon (146 crossings) to strike both sky-high bells and deep pillars",
            },
        ],
        "stages": [
            {
                "pass": "A1",
                "pillar": 1,
                "title": "闪电起跑 · 左手飞越右手的空中芭蕾",
                "title_en": "Lightning Launch · Left Hand Vaults Over Right",
                "desc": "零秒起飞！右手在中音区疾驰，左手一秒钟内先踩低音 G3、再翻过右手敲响高音 B4，令人眼花缭乱。",
                "desc_en": "Zero-second liftoff! Right hand races down the center as the left vaults from low G3 right over top to high B4.",
                "focus": "听高音区“叮—叮—”跳跃闪烁的孤星，那全是从底下飞越过来的手弹的！",
                "focus_en": "Hear those sparkling high 'ping–ping' stars? They're played by the hand leaping over from below!",
            },
            {
                "pass": "A2",
                "pillar": 1,
                "title": "极速重演 · 银铃与丝绸的双层透视",
                "title_en": "A-Repeat · Silver Bells Over Purring Silk",
                "desc": "17.4 秒无缝折返，任奫灿进一步压低中间流水的音量，让上下跳跃的远距离音程更加晶莹剔透。",
                "desc_en": "Seamless repeat at 17.4s: Lim hushes the central stream so the wide-leaping outer notes gleam like stars.",
                "focus": "把耳朵拉远一点，同时听见“高空星点+中间旋风+脚底基石”三层幻觉",
                "focus_en": "Zoom out to hear how two hands create the illusion of three separate layers",
            },
            {
                "pass": "B1",
                "pillar": 17,
                "title": "角色倒置 · 换右手开启高空跳伞",
                "title_en": "Role Inversion · Right Hand Takes the High-Wire Jump",
                "desc": "35.4 秒冲入后院，左手接管飞速旋转的音流，换右手在它头顶与脚底之间大跨度弹跳穿梭。",
                "desc_en": "Hurtling into B1 at 35.4s, the left hand takes over the spinning stream while the right vaults across it.",
                "focus": "留意第 25 柱起双手一齐化作连绵十六分音符平行俯冲的壮观浪潮",
                "focus_en": "Listen around Pillar 25 as both hands lock into parallel cascades racing toward the finish",
            },
            {
                "pass": "B2",
                "pillar": 17,
                "title": "飓风冲线 · 七十八秒的屏息奇迹",
                "title_en": "Hurricane Photofinish · Seventy-Eight Seconds of Pure Electricity",
                "desc": "54.2 秒最后冲刺，两只手像两道纠缠的闪电俯冲到底，在清脆利落的主音上瞬间收束！",
                "desc_en": "Launching the final lap at 54.2s, twin bolts of lightning spiral downward to a breathtaking pinpoint landing.",
                "focus": "听最后八根金柱双手贴地疾飞却颗颗如珍珠落玉盘的清晰度",
                "focus_en": "Marvel at the pearl-clear articulation right through the final headlong plunge",
            },
        ],
        "cues": [
            {"pass": "A1", "pillar": 1, "label": "闪电起飞与三次八度大越位", "label_en": "Lightning Liftoff & Cross-Hand Leaps"},
            {"pass": "A2", "pillar": 9, "label": "高空银铃连续闪烁", "label_en": "Sparkling High-Register Bells"},
            {"pass": "B1", "pillar": 17, "label": "惊险换手：左手接管疾风漩涡", "label_en": "Daredevil Swap: Left-Hand Whirlwind"},
            {"pass": "B2", "pillar": 25, "label": "双手平行闪电俯冲终点", "label_en": "Twin-Hand Cascade to the Finish"},
        ],
    },

    6: {
        "code": "Var. 6",
        "code_en": "Var. 6",
        "title": "第六变奏 · 二度卡农：高一级的甜蜜追逐与擦肩火花",
        "title_en": "Variation 6 · Canon at the Second: One Step Higher, Rubbing Shoulders Down the Stairs",
        "subtitle": "二度卡农 · G大调 · 3/8拍 · 单排键（1 Clav.）",
        "subtitle_en": "Canone alla Seconda · G major · 3/8 · Single Manual (1 Clav.)",
        "category": "canon",
        "triad": 2,
        "canonInterval": 2,
        "canonInverted": False,
        "keyMode": "G major",
        "manuals": "1 Clav.",
        "limHighlight": False,
        "noviceHook": (
            "第二座卡农里程碑！如果第 3 变奏是踩着同一双脚印追，这一首里追赶者故意站到“高一级台阶”上往下滑梯——"
            "两个人贴得太近（只差一个二度音），一路擦肩碰撞出蜜糖般酸甜的火花！"
        ),
        "noviceHook_en": (
            "Canon Milestone #2! Instead of starting on the same step, the Follower stands one stair higher and slides down right "
            "behind the Leader—so close together (just a 2nd apart) that their shoulders rub into sweet-and-tart sparks!"
        ),
        "recipe": (
            "来到第二组三联画的收官格，卡农音程从“同度”拉开到“二度”（音程距离 = 2）：领唱声部从高音 G5 顺着音阶轻盈滑落，"
            "仅仅一小节后，追随声部从高一级的 A5 滑落追赶！因为二度是音乐里最贴身的距离，每当一个声部停住喘气、另一个声部追上来时，"
            "就会贴面撞出温柔的二度挂留音，随即又立刻化开为悦耳的三度，全曲交织出多达 180 次声部穿插！"
        ),
        "recipe_en": (
            "Closing Triad 2, the canonic interval widens from Unison to the Second (Interval = 2): the Leader glides down a "
            "scale from G5, and one tiny 3/8 bar later the Follower launches one step higher on A5! Because a second is the "
            "closest neighbor on the keyboard, every sustained note brushes deliciously against its pursuer before melting into "
            "sweet thirds, generating 180 voice crossings over a nimble 3/8 bass."
        ),
        "limNote": (
            "短短 1 分 17 秒（76.6 秒），任奫灿没有把这首学术气息浓厚的二度卡农弹成严肃练习曲，而是赋予它秋叶随风打旋般的灵动滑翔感。"
            "在 17.3 秒 A2 与 53.2 秒 B2 反复中，他把每一处贴身二度的“微酸”摩擦与瞬间融化的“微甜”对比得细腻入微。"
        ),
        "limNote_en": (
            "In a fleet, sunlit 1:17 (76.6s), Yunchan Lim turns rigorous contrapuntal craft into autumn leaves swirling on a breeze. "
            "Listen in the A2 (17.3s) and B2 (53.2s) repeats to how tenderly he cushions each close-quarters second-interval rub "
            "before letting it melt into liquid thirds."
        ),
        "voicesMeta": [
            {
                "name": "滑梯领唱者（Dux）",
                "name_en": "Descending Leader (Dux)",
                "role": "从高音 G5 长音俯冲而下，率先划出一串串轻巧的下行音阶弧线",
                "role_en": "Glides down from a sustained G5 in graceful descending scale cascades",
            },
            {
                "name": "高二度追随者（Comes）",
                "name_en": "Follower a 2nd Higher (Comes)",
                "role": "晚一小节从高一级的 A5 出发，与领唱者贴身擦肩 180 次，撞出酸甜挂留音",
                "role_en": "Enters one bar later a step higher on A5, brushing shoulders 180 times in sweet suspensions",
            },
            {
                "name": "轻快三八拍低音",
                "name_en": "Nimble 3/8 Ground Bass",
                "role": "像碎步小跑的伴奏舞者，在脚下轻巧勾勒 32 根金柱轮廓",
                "role_en": "Patter-steps lightly in 3/8 time, keeping the 32 harmonic pillars buoyant",
            },
        ],
        "stages": [
            {
                "pass": "A1",
                "pillar": 1,
                "title": "高低滑梯 · G5 与 A5 的贴身出发",
                "title_en": "Twin Slides · G5 Followed Right Away by A5",
                "desc": "第 1 柱 G5 刚拉响一秒半，第 2 柱更高一格的 A5 就紧贴着挤进来，立刻擦出第一朵火花！",
                "desc_en": "Barely a second after G5 rings out, A5 squeezes in one step higher—sparking the first delicious rub!",
                "focus": "听开头第 2 秒两个长音紧挨在一起“嗡”地摩擦再滑开的奇妙质感",
                "focus_en": "Catch that close 'buzz-and-melt' rub in second 2 when A5 leans against G5",
            },
            {
                "pass": "A2",
                "pillar": 1,
                "title": "流光追逐 · 下行音阶如珠帘垂落",
                "title_en": "A-Repeat · Beaded Curtains of Cascading Scales",
                "desc": "17.3 秒重返前院，两串下行音阶像前后摇晃的水晶珠帘，在阳光下折射出细碎光芒。",
                "desc_en": "Repeating from 17.3s, twin descending scales shimmer like two layers of a crystal bead curtain.",
                "focus": "感受一高一低两条滑梯接连俯冲的波浪起伏",
                "focus_en": "Ride the overlapping wave-crests as Leader and Follower cascade in turn",
            },
            {
                "pass": "B1",
                "pillar": 17,
                "title": "向上攀援 · 滑梯翻转为登山石阶",
                "title_en": "B-Section Climb · Slides Turn into Ascending Steps",
                "desc": "35.4 秒进入后半程，旋律改为一阶阶向上试探攀升，小调色彩让贴身追逐多了一分温柔叹息。",
                "desc_en": "At 35.4s the canon turns upward in yearning chromatic-tinged steps through E-minor territory.",
                "focus": "听第 21–24 柱在小调阴影里愈发缠绵的贴身对位",
                "focus_en": "Listen to the heightened expressive sighs in the E-minor stretch (Pillars 21–24)",
            },
            {
                "pass": "B2",
                "pillar": 17,
                "title": "轻盈归港 · 风吹落叶悄然着陆",
                "title_en": "Featherlight Landing · Swirling Gently to Rest",
                "desc": "53.2 秒开启最后半程，任奫灿在尾声不做夸张渐慢，像一阵清风吹过树梢自然散去。",
                "desc_en": "From 53.2s to the end, Lim lets the swirling scales settle with effortless, unforced grace.",
                "focus": "听结尾最后两柱由绚烂跑动突然收归平静单音的呼吸转换",
                "focus_en": "Catch the poised hush at Pillar 32 as the rapid scales come cleanly to rest",
            },
        ],
        "cues": [
            {"pass": "A1", "pillar": 1, "label": "G5 与 A5 贴身二度擦出首朵火花", "label_en": "G5 & A5 Close-Quarters Rub"},
            {"pass": "A2", "pillar": 9, "label": "双层珠帘音阶连环滑落", "label_en": "Overlapping Scale Cascades"},
            {"pass": "B1", "pillar": 17, "label": "方向反转：携手向高处攀登", "label_en": "B1 Turn: Ascending Canon Steps"},
            {"pass": "B2", "pillar": 29, "label": "清风拂叶般轻巧收尾", "label_en": "Featherlight Final Landing"},
        ],
    },

    7: {
        "code": "Var. 7",
        "code_en": "Var. 7",
        "title": "第七变奏 · 西西里牧笛吉格：溪水边的足尖轻舞",
        "title_en": "Variation 7 · Siciliano-Gigue: Pastoral Flute Skipping Beside a Brook",
        "subtitle": "吉格舞曲速度 · G大调 · 6/8拍 · 单排或双排键（1 ô vero 2 Clav.）",
        "subtitle_en": "Al tempo di Giga · G major · 6/8 · 1 or 2 Manuals (1 ô vero 2 Clav.)",
        "category": "character",
        "triad": 3,
        "canonInterval": None,
        "canonInverted": False,
        "keyMode": "G major",
        "manuals": "1 ô vero 2 Clav.",
        "limHighlight": False,
        "noviceHook": (
            "听那“长—短—长—短”一蹦一跳的附点节奏！就像阳光明媚的春日草地上，牧童吹着短笛蹦跳前行，"
            "连脚底下的低音石头都跟着快活地眨起眼睛（缀满了小巧颤音）！"
        ),
        "noviceHook_en": (
            "Hear that skipping 'long-short, long-short' dotted lilt! A shepherd's pipe dances across a sunny meadow while even "
            "the bass stones underneath wink with playful little trills!"
        ),
        "recipe": (
            "巴赫在自己的珍藏印本上亲笔补注了“al tempo di Giga”（按吉格舞曲速度），为第三组三联画开启一扇清新田园窗。"
            "全曲只有上下两个绝不越界（0 次交叉！）的清澈声部：高音唱着带附点跳跃的西西里/法国吉格牧歌，低音则每隔几步就吐出一串"
            "俏皮的下波音装饰，仿佛两个人在溪流两岸隔水相望、互相抛掷花环。"
        ),
        "recipe_en": (
            "In his personal copy of the printed score, Bach penciled 'al tempo di Giga' over Variation 7, opening Triad 3 "
            "with pastoral charm. Only two crystal-clear voices appear—zero crossings from start to finish! Above, a lilting "
            "6/8 dotted melody skips like a baroque flute; below, the 32 ground-bass pillars twinkle with witty mordents and "
            "agile octave leaps, tossing garlands back across a sunlit brook."
        ),
        "limNote": (
            "老一辈钢琴家常把这首弹成慢悠悠的摇篮曲，任奫灿却忠实遵照巴赫手稿指示，在 1 分 44 秒（103.5 秒）里弹出轻盈灵巧的吉格舞步！"
            "更妙的是 23.9 秒 A2 与 74.1 秒 B2 反复时，他让左手的波音装饰听起来像大管或拨弦鲁特琴般俏皮咕哝，右手高音则在最后攀上晶莹的 G5 泛音。"
        ),
        "limNote_en": (
            "Honoring Bach's handwritten 'al tempo di Giga' marking in a buoyant 1:44 (103.5s), Yunchan Lim avoids sleepy "
            "heaviness in favor of spring-water grace. On the A2 (23.9s) and B2 (74.1s) repeats, his left-hand mordents chuckle "
            "like a plucked lute while the right hand floats up to a luminous high G5 bell at the close."
        ),
        "voicesMeta": [
            {
                "name": "牧笛附点歌调",
                "name_en": "Skipping Pastoral Flute Line",
                "role": "在高音区以“长—短”附点节奏轻快跳跃，洋溢田园晨风般的欢欣",
                "role_en": "Skips aloft in infectious 6/8 dotted rhythms with open-air pastoral charm",
            },
            {
                "name": "眨眼波音低音柱",
                "name_en": "Twinkling Ornamented Bass",
                "role": "一边踏稳 32 根金柱，一边频频抖出俏皮波音与八度跳跃回应高音",
                "role_en": "Marks the 32 pillars with cheeky mordents and nimble leaps across the brook",
            },
        ],
        "stages": [
            {
                "pass": "A1",
                "pillar": 1,
                "title": "溪畔起舞 · 高低呼应的田园牧歌",
                "title_en": "Meadow Skip · Flute and Lute Across the Brook",
                "desc": "右手刚跳出清脆附点旋律，左手立刻在第一拍抖出一个小颤音眨眼回应，瞬间满室生春。",
                "desc_en": "Right hand skips out on B4 while the left hand winks back immediately with a crisp mordent on G3.",
                "focus": "听左手低音每隔一小节“嘟噜”一下的小颤音装饰",
                "focus_en": "Catch the charming little 'brrr' mordent winks in the left-hand bass",
            },
            {
                "pass": "A2",
                "pillar": 1,
                "title": "春光重现 · 足尖不沾泥的呼吸弹性",
                "title_en": "A-Repeat · Weightless Toe-Pointing Bounce",
                "desc": "23.9 秒回到起点，任奫灿通过更轻巧的断连对比，让附点节奏像小鹿跳过溪石一样轻盈。",
                "desc_en": "Repeating at 23.9s, Lim refines the articulation so every dotted leap skips weightlessly from stone to stone.",
                "focus": "感受高音短促音符轻轻弹起、绝不黏滞的空气感",
                "focus_en": "Feel the airy lift between the long and short notes of the 6/8 lilt",
            },
            {
                "pass": "B1",
                "pillar": 17,
                "title": "林间微云 · 小调叹息与挂留柔光",
                "title_en": "Passing Cloud · Velvet Minor Sighs in the Woods",
                "desc": "47.4 秒步入后半程，欢蹦的舞步忽然放柔，在小调树影里拉出几声悠长婉转的歌唱叹息。",
                "desc_en": "Entering B1 at 47.4s, the carefree skipping melts briefly into long, wistful minor-key sighs.",
                "focus": "留意第 21–24 柱一朵薄云掠过阳光草地般的温柔阴影",
                "focus_en": "Savor the brief cloud passing over the meadow around Pillars 21–24",
            },
            {
                "pass": "B2",
                "pillar": 17,
                "title": "飞向树梢 · 高音 G5 的晶莹留白",
                "title_en": "Treetop Bell · Floating Up to High G5",
                "desc": "74.1 秒最后一遍漫游，结尾处右手没有往下落，反而轻巧跃上高音 G5，像鸟儿停上最高枝头！",
                "desc_en": "In B2 (from 74.1s), instead of dropping down at the end, the melody floats upward to perch on a gleaming high G5!",
                "focus": "听最后一根柱子右手轻飘飘停在高处不肯下来的惊喜收尾",
                "focus_en": "Wait for the delightful upward float onto high G5 right at Pillar 32",
            },
        ],
        "cues": [
            {"pass": "A1", "pillar": 1, "label": "牧笛跳跃与左手眨眼波音", "label_en": "Skipping Flute & Bass Mordent Wink"},
            {"pass": "A2", "pillar": 9, "label": "阳光奔涌的 D 大调小山坡", "label_en": "Sunny D-Major Hillside"},
            {"pass": "B1", "pillar": 21, "label": "薄云掠过：小调里的温柔长叹", "label_en": "Passing Cloud: Tender Minor Sigh"},
            {"pass": "B2", "pillar": 31, "label": "尾声惊喜跃上高枝 G5", "label_en": "Upward Float to Treetop G5"},
        ],
    },

    8: {
        "code": "Var. 8",
        "code_en": "Var. 8",
        "title": "第八变奏 · 双层喷泉：此起彼伏的香槟音浪",
        "title_en": "Variation 8 · Twin Fountains: Interlocking Champagne Cascades",
        "subtitle": "双排键炫技曲 · G大调 · 3/4拍 · 双排键（2 Clav.）",
        "subtitle_en": "Two-Manual Toccata · G major · 3/4 · Two Manuals (2 Clav.)",
        "category": "virtuoso",
        "triad": 3,
        "canonInterval": None,
        "canonInverted": False,
        "keyMode": "G major",
        "manuals": "2 Clav.",
        "limHighlight": False,
        "noviceHook": (
            "就像两座阳光下的音乐喷泉轮流向天空喷射水柱！右手刚冲上一串十一个音的浪花，左手立刻从水底接力冲上另一串，"
            "满耳都是金灿灿的水珠飞溅声！"
        ),
        "noviceHook_en": (
            "Two sunlit fountains jetting skyward in turn! Right hand launches an eleven-note spray of sparkling water, left hand "
            "answers immediately from underneath—drenching the hall in golden light!"
        ),
        "recipe": (
            "这是除《咏叹调》外第一首强制要求“双排键”（2 Clav.）的纯正巴洛克双层托卡塔。巴赫设计了一个极具辨识度的“11 音上冲浪花”公式"
            "（每小节 1 个短休止 + 11 个飞奔十六分音符，或 5 个八分音符对 11 个十六分音符）：两只手在同一音区交错穿插 70 次，"
            "后半段甚至双手同时化作三十二分音符与十六分音符的飞瀑倾泻而下，灿烂夺目！"
        ),
        "recipe_en": (
            "The first variation after the Aria explicitly demanding Two Manuals ('2 Clav.'), Variation 8 runs on an exhilarating "
            "hydraulic engine: surging eleven-note sixteenth-note jets fired back and forth between the hands across 70 voice "
            "crossings. In Part B the fountains double their pressure, sending dazzling thirty-second-note sprays cascading down "
            "from the top of the keyboard!"
        ),
        "limNote": (
            "在 1 分 45 秒（104.7 秒）里，任奫灿把现代斯坦威弹出了管风琴明亮哨管般的辉煌共鸣！24.6 秒 A2 反复时他巧妙突出左手向上拱起的低音弧线，"
            "而到了 74.7 秒 B2 反复的后半段，高空倾泻的三十二分音符如碎钻洒满舞台，指尖控制力令人叹为观止。"
        ),
        "limNote_en": (
            "Over 1:45 (104.7s), Yunchan Lim draws organ-bright brilliance from the Carnegie Steinway. On the A2 repeat (24.6s) "
            "he brings out the surging left-hand counter-jets, and in B2 (74.7s) the high thirty-second-note cascades shower "
            "down like crushed diamonds without ever losing rhythmic poise."
        ),
        "voicesMeta": [
            {
                "name": "上层喷泉水柱",
                "name_en": "Upper Fountain Cascade",
                "role": "以每小节十一颗十六分音符向高空喷涌，后段更绽放三十二分音符碎钻飞瀑",
                "role_en": "Fires eleven-note sixteenth jets skyward and bursts into glittering thirty-second cascades in Part B",
            },
            {
                "name": "下层交错涌泉",
                "name_en": "Interlocking Lower Jet & Bass",
                "role": "既稳踏金柱根基，又频频冲入中音区与右手交错（70 次越位）接力喷发",
                "role_en": "Anchors the harmonic pillars while surging upward across 70 crossings to trade fountain jets",
            },
        ],
        "stages": [
            {
                "pass": "A1",
                "pillar": 1,
                "title": "喷泉齐发 · 十一音水柱交替冲天",
                "title_en": "Fountains Ignite · Eleven-Note Jets Skyward",
                "desc": "0.3 秒起右手率先端出拱形水花，左手踏稳和弦根音后立刻接力向上翻涌，光彩照人。",
                "desc_en": "From 0.3s the right hand launches arching arpeggio jets while the left hand answers with bold upward surges.",
                "focus": "感受每一小节都像波浪“吸一口气—哗啦冲上去”的畅快推力",
                "focus_en": "Ride each bar's 'gather-and-whoosh-upward' fountain surge",
            },
            {
                "pass": "A2",
                "pillar": 1,
                "title": "水雾交织 · 听见左手的反向上冲",
                "title_en": "A-Repeat · Spotlight on the Surging Left Hand",
                "desc": "24.6 秒进入第二遍前院，试着把注意力移到底下：左手也在不断冲出同样辉煌的音浪！",
                "desc_en": "At 24.6s shift your ear downward: notice how the left hand fires its own matching rockets into the treble!",
                "focus": "听第 9–16 柱双手在同一音区你来我往无缝接棒",
                "focus_en": "Hear both hands trading interlocking waves right in the middle register",
            },
            {
                "pass": "B1",
                "pillar": 17,
                "title": "飞瀑加压 · 碎钻般的三十二分音符",
                "title_en": "Double Pressure · Crushed-Diamond Cascades",
                "desc": "48.7 秒跨入后院，喷泉水压骤增！高空突然炸开速度翻倍的细密水花，沿着台阶奔泻而下。",
                "desc_en": "Crossing into B1 at 48.7s, water pressure doubles as dazzling thirty-second-note sprays burst high overhead.",
                "focus": "捕捉第 20 柱前后高音区突然变密一倍的闪亮飞瀑声",
                "focus_en": "Listen around Pillar 20 for the sudden double-speed diamond spray from above",
            },
            {
                "pass": "B2",
                "pillar": 17,
                "title": "金光满堂 · 辉煌澄澈的凯旋收束",
                "title_en": "Sun-Drenched Finale · Radiant Cascade to Home",
                "desc": "74.7 秒开启最后巡礼，双手在密集交错后顺着宽广琶音奔涌归海，留下一片璀璨阳光。",
                "desc_en": "From 74.7s to 1:45, twin cascades interlock in exhilarating symmetry before pouring cleanly into G major.",
                "focus": "享受最后四柱水花四溅却落点精准无比的爽朗收尾",
                "focus_en": "Bask in the sunlit clarity as both fountains land squarely on Pillar 32",
            },
        ],
        "cues": [
            {"pass": "A1", "pillar": 1, "label": "第一束十一音香槟水柱升空", "label_en": "Opening Eleven-Note Fountain Jet"},
            {"pass": "A2", "pillar": 9, "label": "双手交错接力喷涌", "label_en": "Interlocking Two-Hand Cascades"},
            {"pass": "B1", "pillar": 20, "label": "高空炸开三十二分音符碎钻飞瀑", "label_en": "Glittering 32nd-Note Spray"},
            {"pass": "B2", "pillar": 29, "label": "双泉合流，璀璨归家", "label_en": "Twin Fountains Converge Home"},
        ],
    },

    9: {
        "code": "Var. 9",
        "code_en": "Var. 9",
        "title": "第九变奏 · 三度卡农：肩并肩漫步的挚友二重唱",
        "title_en": "Variation 9 · Canon at the Third: Two Old Friends Singing Arm in Arm",
        "subtitle": "三度卡农 · G大调 · 4/4拍 · 单排键（1 Clav.）",
        "subtitle_en": "Canone alla Terza · G major · 4/4 · Single Manual (1 Clav.)",
        "category": "canon",
        "triad": 3,
        "canonInterval": 3,
        "canonInverted": False,
        "keyMode": "G major",
        "manuals": "1 Clav.",
        "limHighlight": False,
        "noviceHook": (
            "刚刚走过第 8 变奏的喷泉喧嚣，空气突然安静温柔下来。听这两条旋律：不再像同度那样抢同一双鞋，也不像二度那样挤得酸涩，"
            "而是隔着最悦耳的“三度”距离肩并肩散步，连底下的低音都忍不住跟着唱起歌来！"
        ),
        "noviceHook_en": (
            "After Variation 8's dazzling fountains, the air turns intimate and warm. No longer crowding onto the same note or "
            "rubbing shoulders a second apart, the two voices stroll arm in arm at the sweetest interval in music—the Third!"
        ),
        "recipe": (
            "第三座卡农里程碑将音程拓宽至人类耳朵最感舒适甜美的“三度”（音程距离 = 3）：领唱声部从温和的 B4 起步，"
            "追随声部在一小节后从低三度的 G4 温柔应和。正因为上方两人的三度/六度重唱如此熨帖，巴赫把最精彩的自由发挥留给了第三声部——"
            "一条充满歌唱气息、上下蜿蜒流动的自由低音旋律，让整首曲子宛如温暖的黄昏室内三重唱。"
        ),
        "recipe_en": (
            "Canon Milestone #3 reaches the sweetest interval of Western harmony—the Third (Interval = 3): the Leader opens "
            "gently on B4, and one bar later the Follower answers a third lower on G4. Because the twin upper voices blend in "
            "velvet thirds and sixths (still crossing 48 times!), Bach gives the third voice an extraordinarily expressive, "
            "melodically active walking counter-bass, creating an intimate twilight trio."
        ),
        "limNote": (
            "在 1 分 50 秒（109.5 秒）的篇幅中，任奫灿弹出摄人心魄的抒情歌唱感（Cantabile）。他故意不把卡农声部弹得棱角分明，"
            "而是让两条高音像女高音与女中音般水乳交融，同时在 25.0 秒 A2 与 77.4 秒 B2 反复里轻轻托出左手大提琴般悠长的低音歌唱线。"
        ),
        "limNote_en": (
            "Across a glowing 1:50 (109.5s), Yunchan Lim shapes Variation 9 with pure vocal warmth. Rather than spotlighting "
            "the canon mechanically, he blends the soprano and alto lines like two human voices breathing together while letting "
            "the left-hand counter-bass sing out like a solo cello in the A2 (25.0s) and B2 (77.4s) repeats."
        ),
        "voicesMeta": [
            {
                "name": "抒情领唱女高音（Dux）",
                "name_en": "Lyric Soprano Leader (Dux)",
                "role": "从温暖的 B4 悠然起唱，句幅舒展如黄昏散步时的轻声倾诉",
                "role_en": "Opens gently on B4 with flowing, songful phrases full of quiet warmth",
            },
            {
                "name": "低三度挚友（Comes）",
                "name_en": "Alto Follower a 3rd Below (Comes)",
                "role": "晚一小节在低三度的 G4 默契相随，编织出蜜糖般柔和的三度与六度和声",
                "role_en": "Answers one bar later a third lower on G4, bathing the texture in sweet thirds and sixths",
            },
            {
                "name": "歌唱对位低音",
                "name_en": "Singing Cello Counter-Bass",
                "role": "不仅承载 32 根金柱，更化作一条流动自如的大提琴旋律与上方二重唱深情对话",
                "role_en": "Carries the 32 pillars inside a rich, melodically independent cello-like counter-subject",
            },
        ],
        "stages": [
            {
                "pass": "A1",
                "pillar": 1,
                "title": "并肩漫步 · B4 与 G4 的黄金三度重唱",
                "title_en": "Arm in Arm · B4 and G4 Blend in Sweet Thirds",
                "desc": "领唱者刚迈出四步，挚友便从低三度稳稳挽住它的手臂，脚下大提琴低音也随之流淌开来。",
                "desc_en": "Four beats after B4 steps out, G4 links arms a third below while the rich cello bass begins its flowing song.",
                "focus": "感受和前两首卡农截然不同的松弛、甘美与和谐感",
                "focus_en": "Feel the immediate honeyed warmth compared to the tighter Unison and 2nd canons",
            },
            {
                "pass": "A2",
                "pillar": 1,
                "title": "倾听低音 · 第三位隐藏的独唱家",
                "title_en": "A-Repeat · Discover the Singing Cello Below",
                "desc": "25.0 秒回到起点，这次把耳朵沉到最底下：听左手那条上下起伏的十六分音符低音有多么动听！",
                "desc_en": "At 25.0s drop your ear to the bottom layer: hear how expressively the left-hand bass sings and arches!",
                "focus": "追踪左手低音像溪流绕石般圆润连贯的歌唱线条",
                "focus_en": "Follow the supple, arching sixteen-note phrases in the left hand",
            },
            {
                "pass": "B1",
                "pillar": 17,
                "title": "暮色倾诉 · 小调深处的温柔依偎",
                "title_en": "Twilight Confession · Leaning Closer in Minor Shade",
                "desc": "51.5 秒跨入后院，两位挚友步入幽静的 E 小调长廊，半音叹息让这段对话显得格外真挚动人。",
                "desc_en": "Entering B1 at 51.5s, the duet wanders into velvet minor shadows tinged with tender chromatic sighs.",
                "focus": "听第 21–24 柱三层声部像室内弦乐团一样呼吸起伏",
                "focus_en": "Savor the string-trio intimacy through the E-minor heart of Part B",
            },
            {
                "pass": "B2",
                "pillar": 17,
                "title": "灯火归家 · 温暖不散的拥抱收束",
                "title_en": "Warm Hearth · Unhurried Embrace at Home",
                "desc": "77.4 秒走完最后半程，没有喧哗，只有三位老友在灯火可亲的家门口轻轻点头道别。",
                "desc_en": "From 77.4s to 1:50, all three singing lines settle peacefully home like old friends parting by warm lamplight.",
                "focus": "听结尾处低音先缓缓走完音阶，高音再静静落定的从容感",
                "focus_en": "Listen to the gentle bass scale guiding the twin upper voices peacefully home",
            },
        ],
        "cues": [
            {"pass": "A1", "pillar": 1, "label": "黄金三度二重唱温暖开启", "label_en": "Warm Canon at the Third Begins"},
            {"pass": "A2", "pillar": 5, "label": "左手大提琴低音悠扬歌唱", "label_en": "Singing Left-Hand Cello Line"},
            {"pass": "B1", "pillar": 21, "label": "暮色小调里的弦乐三重奏质感", "label_en": "Velvet Minor String-Trio Glow"},
            {"pass": "B2", "pillar": 29, "label": "灯火归家般的宁静收尾", "label_en": "Tranquil Lamplight Close"},
        ],
    },

    10: {
        "code": "Var. 10",
        "code_en": "Var. 10",
        "title": "第十变奏 · 小赋格：由地底向穹顶逐层砌起的四声部哥特塔楼",
        "title_en": "Variation 10 · Fughetta: A Four-Story Gothic Tower Built from Cellar to Spire",
        "subtitle": "四声部小赋格 · G大调 · 4/4拍 · 单排键（1 Clav.）",
        "subtitle_en": "Fughetta (4 Voices) · G major · 4/4 · Single Manual (1 Clav.)",
        "category": "character",
        "triad": 4,
        "canonInterval": None,
        "canonInverted": False,
        "keyMode": "G major",
        "manuals": "1 Clav.",
        "limHighlight": False,
        "noviceHook": (
            "这是最容易“数清楚声部”的一首神奇建筑课！每隔四根柱子（约 5.5 秒），就会有一位新歌者带着同一句神气的带颤音口号加入合唱——"
            "从最底层的男低音一路叠到最高层的女高音，眼睁睁看着一栋四层哥特小塔拔地而起！"
        ),
        "noviceHook_en": (
            "The easiest and most thrilling architecture lesson in the whole work! Every four pillars (~5.5 seconds), a brand-new "
            "voice marches in singing the exact same trilled motto—stacking four stories from cellar bass right up to sunlit spire!"
        ),
        "recipe": (
            "第四组三联画以一首微型四声部赋格（Fughetta）庄严开篇。最绝妙的是巴赫把前 8 根黄金立柱直接雕塑成了四小节长的“赋格主题”！"
            "前院 A 段就是完整的四层筑塔过程：第 1 柱男低音孤身起唱（G3）→ 第 5 柱次中音在二楼接棒（D4）→ 第 9 柱女高音直接亮出四楼塔尖（G5）"
            "→ 第 13 柱女中音补齐三楼（A4/D5），整整 16 根柱子刚好砌满四层声部！后院 B 段则让四位歌者在塔楼间穿梭应答。"
        ),
        "recipe_en": (
            "Triad 4 opens with a miniature four-voice Fughetta where Bach carves Pillars 1–4 directly into a bold four-bar "
            "fugal subject crowned with mordents! All of Courtyard A is one glorious four-story construction sequence: Bass "
            "alone at Pillar 1 (G3) → Tenor at Pillar 5 (D4) → gleaming Soprano spire at Pillar 9 (G5) → Alto completing the "
            "edifice at Pillar 13—sixteen pillars building four full voices, before Part B sets all four conversing freely!"
        ),
        "limNote": (
            "1 分 43 秒（102.9 秒）里，任奫灿展现出管风琴大师般清晰立体的声部浮雕感！前 22 秒四次主题进入时，每一次新声部亮相都像聚光灯啪地打亮一层新石雕；"
            "而在 22.7 秒 A2 与 68.8 秒 B2 反复中，他把主题上的波音弹得神气活现、充满巴洛克庆典号角的喜悦。"
        ),
        "limNote_en": (
            "In 1:43 (102.9s), Yunchan Lim sculpts the four voices with pipe-organ architectural clarity. Across the opening "
            "22 seconds, each of the four subject entries lights up like a fresh spotlight hitting carved stone; in the A2 "
            "(22.7s) and B2 (68.8s) repeats, crisp mordents ring out like festive Baroque trumpets."
        ),
        "voicesMeta": [
            {
                "name": "第四棒·中音拼图（第13柱入）",
                "name_en": "4th Entry · Alto Keystone (Pillar 13)",
                "role": "在第 13 柱压轴填入中音层，为四声部赋格塔楼镶上最后一块拱顶石",
                "role_en": "Enters fourth at Pillar 13 to lock the final keystone into the four-voice edifice",
            },
            {
                "name": "第三棒·塔尖女高音（第9柱入）",
                "name_en": "3rd Entry · Soprano Spire (Pillar 9)",
                "role": "在第 9 柱高音 G5 璀璨亮嗓，一下子把建筑视野拔升至晴空顶端",
                "role_en": "Crowns the tower on bright high G5 at Pillar 9, lifting the roof toward the sky",
            },
            {
                "name": "第二棒·次中音应答（第5柱入）",
                "name_en": "2nd Entry · Tenor Answer (Pillar 5)",
                "role": "在第 5 柱于属音 D4 稳健接唱，搭建起塔楼坚实的第二层拱廊",
                "role_en": "Answers on D4 at Pillar 5, raising the sturdy second story above the bass",
            },
            {
                "name": "第一棒·地基男低音（第1柱入）",
                "name_en": "1st Entry · Bass Foundation (Pillar 1)",
                "role": "开篇独自唱响由黄金立柱化身的四小节赋格主题，奠定全塔基石",
                "role_en": "Strides in solo at Pillar 1 with the bold mordent-crowned Ground-Bass fugue subject",
            },
        ],
        "stages": [
            {
                "pass": "A1",
                "pillar": 1,
                "title": "一层与二层 · 男低音奠基，次中音接棒",
                "title_en": "Stories 1 & 2 · Solo Bass Foundation, Tenor Answer",
                "desc": "0.0 秒男低音独自庄严唱出带颤音的四柱口号；第 5 柱（约 5.6 秒）次中音准时在二楼接唱同一口号！",
                "desc_en": "Bass enters completely alone at 0.0s with the trilled motto; at Pillar 5 (~5.6s) Tenor answers one story higher!",
                "focus": "伸出手指跟着数：0 秒第 1 人开唱，第 5 柱第 2 人加入！",
                "focus_en": "Count on your fingers: Voice 1 solo at 0:00, Voice 2 joins at ~0:06!",
            },
            {
                "pass": "A1",
                "pillar": 9,
                "title": "三层与塔尖 · 高音点亮穹顶，四声部合拢",
                "title_en": "Stories 3 & 4 · Soprano Spire & Final Keystone",
                "desc": "第 9 柱（约 11 秒）高音在云端 G5 辉煌唱响第 3 棒，第 13 柱（约 17 秒）第 4 棒补齐中间层，四层宝塔完工！",
                "desc_en": "At Pillar 9 (~11s) Soprano gleams high on G5; at Pillar 13 (~17s) Alto slots in—completing all four stories!",
                "focus": "听第 9 柱高空突然亮灯的惊喜，以及第 13 柱满堂丰满的合唱音响",
                "focus_en": "Hear the thrilling sky-high entrance at Pillar 9 and full 4-part fullness at Pillar 13",
            },
            {
                "pass": "A2",
                "pillar": 1,
                "title": "二次筑塔 · 从满堂辉煌瞬间归于独唱",
                "title_en": "A-Repeat · From Full Choir Back to Lone Stone",
                "desc": "22.7 秒突然从丰满四声部抽空回男低音一个人的独白，让你再过一遍亲手“搭积木”的快感！",
                "desc_en": "At 22.7s the full 4-voice tower suddenly drops back to lone solo bass so you can watch it rise a second time!",
                "focus": "享受 22.7 秒四声部瞬间归零、重新一层层叠高的戏剧反差",
                "focus_en": "Relish the dramatic sudden drop from four voices back to one lone voice at 22.7s",
            },
            {
                "pass": "B1",
                "pillar": 17,
                "title": "后院巡礼 · 颠倒次序的立体交响",
                "title_en": "Courtyard B · Top-Down Fugal Panorama",
                "desc": "45.4 秒跨入后半程，这次改由高音率先发号施令，四个声部在小调与属调间纵横交错对话。",
                "desc_en": "Entering B1 at 45.4s, Soprano leads off first as the subject plunges through minor shadows down into rumbling low bass.",
                "focus": "听后半段最低音区轰鸣响起主题时的管风琴踏板气魄",
                "focus_en": "Wait for the deep bass entry rumbling like organ pedals beneath the upper three voices",
            },
            {
                "pass": "B2",
                "pillar": 17,
                "title": "穹顶竣工 · 庄严敞亮的巴洛克礼赞",
                "title_en": "Grand Keystone · Majestic Four-Part Finale",
                "desc": "68.8 秒开启最后巡礼，四条独立旋律各司其职又浑然一体，稳稳托起光辉灿烂的 G 大调拱门。",
                "desc_en": "From 68.8s to 1:43, all four independent voices stride in triumphant equilibrium to a noble G-major close.",
                "focus": "在最后四柱感受四层声部像四根石柱稳稳合抱的建筑庄严感",
                "focus_en": "Feel all four architectural columns locking into the radiant final cadence",
            },
        ],
        "cues": [
            {"pass": "A1", "pillar": 1, "label": "第 1 棒：男低音孤身奠基", "label_en": "Entry 1: Lone Bass Subject"},
            {"pass": "A1", "pillar": 9, "label": "第 3 棒：高音点亮四楼塔尖 G5", "label_en": "Entry 3: Gleaming Soprano Spire"},
            {"pass": "A2", "pillar": 1, "label": "戏剧抽空：重返单人筑塔", "label_en": "Dramatic Drop Back to Solo Bass"},
            {"pass": "B1", "pillar": 25, "label": "地底管风琴低音轰鸣主题", "label_en": "Deep Organ-Pedal Bass Entry"},
        ],
    },

    11: {
        "code": "Var. 11",
        "code_en": "Var. 11",
        "title": "第十一变奏 · 水银涟漪：两百零六次交错的镜面万花筒",
        "title_en": "Variation 11 · Quicksilver Ripples: A Kaleidoscope of Two Hundred and Six Crossings",
        "subtitle": "双排键托卡塔 · G大调 · 12/16拍 · 双排键（2 Clav.）",
        "subtitle_en": "Two-Manual Toccata · G major · 12/16 · Two Manuals (2 Clav.)",
        "category": "virtuoso",
        "triad": 4,
        "canonInterval": None,
        "canonInverted": False,
        "keyMode": "G major",
        "manuals": "2 Clav.",
        "limHighlight": False,
        "noviceHook": (
            "刚刚砌好第 10 变奏厚重的石头塔楼，石头突然融化成了一池流动的水银！一只手顺着音阶往下流淌，"
            "另一只手同时顺着音阶往上涌起，在键盘正中央穿插交错整整 206 次，丝滑得像风吹丝绸！"
        ),
        "noviceHook_en": (
            "Variation 10's solid stone tower suddenly melts into liquid mercury! One hand glides down a scale while the other "
            "glides up right through it—weaving 206 voice crossings into shimmering, weightless silk!"
        ),
        "recipe": (
            "巴赫选用极为罕见的 12/16 拍（每小节十二颗轻柔滚动的十六分音符），打造出上半场最精妙的双排键流光织体。"
            "听它的魔法配方：起初右手像流水向下滑落、左手同时如微风向上升起，两条反向音阶在半空中擦肩而过；随后又变成双手交叉拍打的"
            "三连音琶音浪花（全曲高达 206 次声部交叉！），悄悄为紧随其后的第 12 变奏“反向镜像卡农”做足了视觉与听觉预告。"
        ),
        "recipe_en": (
            "Cast in a rare, liquid 12/16 meter, Variation 11 weaves the finest filigree toccata of Wing I. Its secret alchemy "
            "is contrary motion and cross-hand shimmer: as one hand ripples smoothly down a scale, the other rises smoothly "
            "up through the exact same keys—interlocking across an astonishing 206 voice crossings and subtly foreshadowing "
            "the upside-down mirror canon coming next in Variation 12!"
        ),
        "limNote": (
            "在 2 分 01 秒（121.4 秒）里，任奫灿没有一味求快，而是弹出梦幻般的“水下光影”（Legatissimo 与晶莹指触并存）。"
            "无论是 29.9 秒的 A2 还是 88.9 秒的 B2，当双手挤在同一个八度里反向穿梭时，他的手腕轻盈得像蜻蜓掠水，连最微小的半音涟漪都清晰可辨。"
        ),
        "limNote_en": (
            "Taking a poised, luminous 2:01 (121.4s), Yunchan Lim resists rushing so every liquid 12/16 ripple gleams like "
            "sunlight through clear water. Across both repeats (A2 at 29.9s, B2 at 88.9s), even when both hands crowd into "
            "the same octave across 206 crossings, his featherlight touch keeps the contrary-motion streams miraculously transparent."
        ),
        "voicesMeta": [
            {
                "name": "水银上层流光",
                "name_en": "Quicksilver Upper Stream",
                "role": "以丝滑的 12/16 音阶与分解三和弦上下游走，如水面上闪烁的碎金涟漪",
                "role_en": "Glides in liquid 12/16 scales and broken triads like sunlit ripples on water",
            },
            {
                "name": "镜面逆流穿梭手",
                "name_en": "Mirroring Cross-Hand Stream",
                "role": "以反向音阶与越位琶音同上层穿插 206 次，暗中勾勒 32 根承重金柱",
                "role_en": "Rises and plunges through the upper voice 206 times while outlining the 32 pillars",
            },
        ],
        "stages": [
            {
                "pass": "A1",
                "pillar": 1,
                "title": "逆向水流 · 一升一降擦肩而过",
                "title_en": "Opposing Streams · Falling Water Meets Rising Breeze",
                "desc": "第一秒右手从 B4 轻柔滑落，左手从 G2 稳步攀升，两股水流在键盘中央温柔穿透彼此。",
                "desc_en": "Right hand ripples gently downward from B4 while the left climbs upward from G2—passing straight through one another.",
                "focus": "闭眼感受两股水流“一上一下”迎面交汇的丝滑摩擦感",
                "focus_en": "Sense the two smooth scale streams gliding in opposite directions",
            },
            {
                "pass": "A2",
                "pillar": 1,
                "title": "穿指万花筒 · 交替闪烁的三连音铃铛",
                "title_en": "A-Repeat · Kaleidoscope of Cross-Hand Triplets",
                "desc": "29.9 秒重返前院，留意第 9–16 柱：双手轮流越过对方手背敲击琶音，像万花筒旋转折射彩光。",
                "desc_en": "Repeating from 29.9s, listen around Pillars 9–16 as hands cross rapidly to spin shimmering arpeggio pinwheels.",
                "focus": "听第 9 柱起水流突然碎成一串串晶莹旋转的风铃声",
                "focus_en": "Catch the texture shifting at Pillar 9 from smooth scales to spinning wind-chimes",
            },
            {
                "pass": "B1",
                "pillar": 17,
                "title": "幽潭微光 · 半音涟漪与高空颤音",
                "title_en": "Deep Pool · Chromatic Ripples & Floating Trills",
                "desc": "59.5 秒进入后院，长长的悬留颤音悬在半空，底下则是带着神秘半音色彩的暗流涌动。",
                "desc_en": "Entering B1 at 59.5s, luminous long trills hover overhead while chromatic ripples eddy mysteriously below.",
                "focus": "听高音长长颤动如蜻蜓振翅，水底暗流蜿蜒盘旋",
                "focus_en": "Hear hovering dragonfly trills above winding chromatic undercurrents",
            },
            {
                "pass": "B2",
                "pillar": 17,
                "title": "水落石出 · 涟漪收拢入镜面平静",
                "title_en": "Mirror Stillness · Ripples Subsiding Cleanly",
                "desc": "88.9 秒走完最后半程，两百多次穿梭最终化作一串向地心轻柔沉落的音阶，悄然停驻。",
                "desc_en": "From 88.9s to 2:01, two hundred crossings subside effortlessly into one final descending ripple.",
                "focus": "听最后两柱水银归槽般一尘不染的收束",
                "focus_en": "Follow the final cascading scale settling into spotless stillness",
            },
        ],
        "cues": [
            {"pass": "A1", "pillar": 1, "label": "一升一降：两股水银迎面穿透", "label_en": "Opposing Quicksilver Scales"},
            {"pass": "A1", "pillar": 9, "label": "万花筒越位风铃旋转开启", "label_en": "Cross-Hand Pinwheel Arpeggios"},
            {"pass": "B1", "pillar": 21, "label": "悬空长颤音与半音幽潭涟漪", "label_en": "Hovering Trills & Chromatic Pool"},
            {"pass": "B2", "pillar": 29, "label": "水银归槽，涟漪收拢", "label_en": "Final Shimmering Descent"},
        ],
    },

    12: {
        "code": "Var. 12",
        "code_en": "Var. 12",
        "title": "第十二变奏 · 反向四度卡农：湖面与天空的第一幅完美倒影",
        "title_en": "Variation 12 · Inverted Canon at the Fourth: Sky and Lake in Perfect Mirror",
        "subtitle": "反向四度卡农 · G大调 · 3/4拍 · 单排键（1 Clav.）",
        "subtitle_en": "Canone alla Quarta in moto contrario · G major · 3/4 · Single Manual (1 Clav.)",
        "category": "canon",
        "triad": 4,
        "canonInterval": 4,
        "canonInverted": True,
        "keyMode": "G major",
        "manuals": "1 Clav.",
        "limHighlight": False,
        "noviceHook": (
            "全曲第一次开启“镜像魔法”！站在湖岸上看：岸上的领唱者每往上迈一步，湖水里的倒影就同时往下沉一步；"
            "岸上往下跳四度，水里就往上跃四度——整首曲子就像一张上下对折分毫不差的剪纸艺术！"
        ),
        "noviceHook_en": (
            "Mirror magic appears for the very first time! Stand at the edge of a glassy lake: every step the Leader takes "
            "upward on shore, its water reflection takes downward; every leap down is answered by an identical leap up!"
        ),
        "recipe": (
            "第四座卡农里程碑（音程距离 = 4 度）迎来了巴赫对位法的一大飞跃——“反向卡农”（in moto contrario）："
            "领唱者从 G4 起步先微微下探再级进上行，一小节后追随者从低四度的 D4 出发，把每一个音程全部上下颠倒过来唱！"
            "为了让你看清这面神奇的水平镜子，巴赫在开篇让低音连敲三下沉稳的四分音符“咚、咚、咚”，像老座钟摆锤一样稳住镜框。"
        ),
        "recipe_en": (
            "Canon Milestone #4 introduces Bach's breathtaking 'in moto contrario' (upside-down mirror) technique! The Leader "
            "steps out on G4, dipping a half-step before climbing; one bar later the Follower enters a fourth below on D4, "
            "turning every upward interval downward and every downward interval upward! Beneath this horizontal mirror axis, "
            "the bass marks stately 'tick–tick–tick' quarter-note footsteps in the opening bars like a grandfather clock."
        ),
        "limNote": (
            "在 2 分 12 秒（132.5 秒）的从容步履中，任奫灿弹出温润高贵的古典风度。他把左手开头的三拍重复低音弹得像柔和的拨弦大提琴，"
            "并在 31.1 秒 A2 与 93.6 秒 B2 反复中，让高音本尊与中音倒影展现出微妙的光泽差异——一个是阳光下的实体，一个是碧水里的柔影。"
        ),
        "limNote_en": (
            "Across an unhurried, noble 2:12 (132.5s), Yunchan Lim illuminates the mirror symmetry with effortless warmth. "
            "Listen to his gentle pizzicato-like poise on the opening repeated quarter-note bass footsteps, and how in A2 (31.1s) "
            "and B2 (93.6s) he differentiates sunlit Leader from softer, water-tinted Follower."
        ),
        "voicesMeta": [
            {
                "name": "湖岸领唱本尊（Dux）",
                "name_en": "Shoreline Leader (Dux)",
                "role": "从 G4 起步舒展歌唱，一举一动都将在一小节后被水面上下翻转映出",
                "role_en": "Steps out warmly on G4; every rise and fall casts an upside-down twin one bar later",
            },
            {
                "name": "水中反向倒影（Comes）",
                "name_en": "Inverted Reflection a 4th Below (Comes)",
                "role": "从 D4 出发严格上下镜像对称（本尊升则倒影降，本尊降则倒影升）",
                "role_en": "Enters on D4 in exact upside-down inversion—falling whenever the Leader rises and vice versa",
            },
            {
                "name": "钟摆步履金柱",
                "name_en": "Clockwork Ground-Bass Stride",
                "role": "开篇以三拍稳健同音敲响黄金立柱，随后化作优雅流畅的装饰低音",
                "role_en": "Opens with stately three-quarter-note footsteps on each pillar before blossoming into flowing runs",
            },
        ],
        "stages": [
            {
                "pass": "A1",
                "pillar": 1,
                "title": "镜面初显 · 钟摆低音与第一道水中倒影",
                "title_en": "Mirror Revealed · Clockwork Bass & First Water Reflection",
                "desc": "先听底下“G—G—G”三声沉稳铺垫：高音刚往上走一串音阶，第 2 柱中音立刻往下一模一样走出倒影！",
                "desc_en": "Over steady 'G–G–G' bass footsteps, the Leader climbs a scale in bar 1—and bar 2 mirrors it downward note for note!",
                "focus": "看视觉画布更直观：一条线往上爬时，另一条影子线必在下一拍往下滑！",
                "focus_en": "Watch and listen together: each upward climb triggers an exact downward mirror image!",
            },
            {
                "pass": "A2",
                "pillar": 1,
                "title": "对称奇观 · 倒影向上托起本尊",
                "title_en": "A-Repeat · Reflection Rising to Meet the Sky",
                "desc": "31.1 秒重游湖畔，当第 9–12 柱领唱者向下轻叹滑落时，水中倒影反而逆流向上托起一片波光。",
                "desc_en": "Repeating at 31.1s, whenever the Leader sighs downward around Pillars 9–12, its reflection buoys gracefully upward.",
                "focus": "感受两股力量像剪刀开合一样呼吸对称的平衡美",
                "focus_en": "Feel the poised 'scissors opening and closing' balance between the two upper voices",
            },
            {
                "pass": "B1",
                "pillar": 17,
                "title": "微风吹皱 · 小调连音与轻巧跳音对话",
                "title_en": "Rippled Glass · Lyrical Sighs & Playful Appoggiaturas",
                "desc": "62.1 秒步入后院，巴赫加入成对的温柔倚音叹息，低音也褪去严肃步伐，化作潺潺流水相伴。",
                "desc_en": "Entering B1 at 62.1s, tender two-note sighing slurs appear in minor light while the bass flows in graceful sixteenths.",
                "focus": "听第 21–24 柱一上一下互相呼应的温柔双音叹气声",
                "focus_en": "Catch the paired two-note sighs mirroring each other upward and downward",
            },
            {
                "pass": "B2",
                "pillar": 17,
                "title": "波平如镜 · 为最美慢板屏息铺路",
                "title_en": "Glassy Calm · Hushing the Stage for Variation 13",
                "desc": "93.6 秒走完最后半圈，任奫灿在尾声缓缓收住力道，湖面重归澄澈无波，静候第 13 变奏的月光降临。",
                "desc_en": "From 93.6s to 2:12, Lim gently tapers the tone until the lake surface lies glassy still, awaiting Variation 13's moonlight.",
                "focus": "听结尾几小节音量自然消退、把心彻底静下来的过渡魔法",
                "focus_en": "Savor the hushed twilight taper preparing the soul for Variation 13",
            },
        ],
        "cues": [
            {"pass": "A1", "pillar": 1, "label": "三声钟摆低音与首道反向镜像", "label_en": "Clockwork Bass & First Mirror Canon"},
            {"pass": "A2", "pillar": 9, "label": "剪刀开合般的上下镜像对称", "label_en": "Opening-and-Closing Mirror Arcs"},
            {"pass": "B1", "pillar": 21, "label": "小调湖面上的双音对偶叹息", "label_en": "Paired Mirror Sighs in E Minor"},
            {"pass": "B2", "pillar": 29, "label": "湖面归于无波，静待月光", "label_en": "Glassy Taper Toward Var. 13"},
        ],
    },

    13: {
        "code": "Var. 13",
        "code_en": "Var. 13",
        "title": "第十三变奏 · 月光银笛圣殿：三十二分音符织成的星空丝缕",
        "title_en": "Variation 13 · Moonlit Flute Sanctuary: Filigree Spun from Starlight",
        "subtitle": "抒情装饰咏叹调 · G大调 · 3/4拍 · 双排键（2 Clav.）",
        "subtitle_en": "Cantabile Sarabande · G major · 3/4 · Two Manuals (2 Clav.)",
        "category": "character",
        "triad": 5,
        "canonInterval": None,
        "canonInverted": False,
        "keyMode": "G major",
        "manuals": "2 Clav.",
        "limHighlight": True,
        "noviceHook": (
            "时间在这一刻突然慢了下来（整整 5 分 20 秒！）。高处飘起一支无比纯净的银色长笛，"
            "每一拍都缀满了羽毛般细腻的三十二分音符花纹，美得让人不敢大声呼吸。"
        ),
        "noviceHook_en": (
            "Time suddenly stands still across five luminous minutes (5:20). High overhead, a lone silver flute spins gossamer "
            "thirty-second-note lacework through moonlit air—music so pure the entire hall forgets to breathe."
        ),
        "recipe": (
            "作为上半场最后一组三联画（第 5 组）的心灵核心，巴赫回到《咏叹调》静谧的三拍子萨拉班德脉搏，"
            "却把高音旋律升华成一条绵延不断、总共包含 1,148 颗音符的无尽歌调！左手在另一层键盘上拆分成两个极简的内声部与低音柱，"
            "只用轻轻点染的和弦托住天空，让右手那条丝绸般的三十二分音符花腔在无重力太空中自由翱翔。"
        ),
        "recipe_en": (
            "Opening the final triad of Wing I, Bach returns to the Aria's 3/4 Sarabande pulse and spins an endless, soaring "
            "right-hand cantilena of 1,148 thirty-second-note filigree notes! Below on the second manual, two quiet accompanying "
            "voices touch the 32 pillars lightly like distant harp plucks, leaving vast zero-gravity space for the upper melody "
            "to float unhindered."
        ),
        "limNote": (
            "这是任奫灿卡内基现场最令人落泪的高光时刻之一（全长 319.6 秒 / 5 分 20 秒）！他的右手触键仿佛没有琴槌敲击的痕迹，"
            "上千颗三十二分音符像月光流过威尼斯玻璃般晶莹圆润；74.2 秒进入 A2、231.7 秒进入 B2 时，大厅安静得连一根针掉地上都听得见，"
            "每一处半音转折都带着超越年龄的慈悲与静谧。"
        ),
        "limNote_en": (
            "One of the supreme miracles of Yunchan Lim's Carnegie Hall recital (319.6s / 5:20)! Hammer percussion seems to "
            "vanish altogether: over a thousand thirty-second notes gleam like moonlight on Venetian glass. Entering A2 at 74.2s "
            "and B2 at 231.7s into pin-drop silence, Lim shapes every chromatic turn with breathless tenderness and luminous stillness."
        ),
        "voicesMeta": [
            {
                "name": "银笛星空花腔",
                "name_en": "Moonlit Flute Cantilena",
                "role": "独自承载 1,148 颗三十二分音符丝缕，在云端织出无边无际的夜曲长歌",
                "role_en": "Spins 1,148 gossamer thirty-second notes aloft in an unbroken nocturnal aria",
            },
            {
                "name": "微光内声部光晕",
                "name_en": "Hushed Inner Halo",
                "role": "在每小节弱拍轻轻托起长音和声，像烛火周围一圈温暖柔和的光晕",
                "role_en": "Enters gently off the beat with sustained inner tones like a warm halo around candlelight",
            },
            {
                "name": "静水承重金柱",
                "name_en": "Still-Water Ground Pillars",
                "role": "以鲁特琴拨弦般的克制步伐点明 32 根金柱，绝不惊扰高空的梦境",
                "role_en": "Touches the 32 harmonic pillars with lute-like restraint beneath the floating song",
            },
        ],
        "stages": [
            {
                "pass": "A1",
                "pillar": 1,
                "title": "月华初降 · 无重力的银色丝线",
                "title_en": "Moonrise · Weightless Silver Thread",
                "desc": "第一拍高音便如露珠滑过花瓣般轻轻旋开，底下左手像竖琴拨弦一样克制而温柔。",
                "desc_en": "From beat one the soprano unfurls weightlessly like dew sliding down a petal over hushed harp-like chords.",
                "focus": "不要去数细碎的音符，把整条高音听成一缕连绵不断的银光",
                "focus_en": "Don't count individual fast notes—hear the top voice as one continuous ribbon of silver light",
            },
            {
                "pass": "A1",
                "pillar": 9,
                "title": "星河舒展 · 攀向澄澈的 D 大调高空",
                "title_en": "Starlit Ascent · Soaring Toward Luminous D Major",
                "desc": "第 9–16 柱旋律层层向上盘旋舒展，每一次微小的半音倚靠都像夜风拂过心尖。",
                "desc_en": "Across Pillars 9–16 the cantilena spirals gently higher, tinged with exquisite expressive leanings.",
                "focus": "感受高音攀上制高点后缓缓飘落回第 16 柱的悠长呼吸",
                "focus_en": "Breathe with the long, arching descent settling gently onto Pillar 16",
            },
            {
                "pass": "A2",
                "pillar": 1,
                "title": "前院重返 · 卡内基大厅的屏息时刻",
                "title_en": "A-Repeat · Pin-Drop Stillness in Carnegie Hall",
                "desc": "74.2 秒重新回到第一缕月光，任奫灿把弱音控制推向极致，声音仿佛从遥远的天际飘来。",
                "desc_en": "Returning to Pillar 1 at 74.2s, Lim whispers the filigree pianissimo as if floating from another world.",
                "focus": "细听左手内声部在第二拍轻轻托住高音的那份温柔默契",
                "focus_en": "Listen into the tender beat-two cushion supporting the floating soprano",
            },
            {
                "pass": "A2",
                "pillar": 9,
                "title": "琉璃光泽 · 半音涟漪里的微笑",
                "title_en": "Venetian Glass · Tender Chromatic Shimmer",
                "desc": "同样走向 D 大调庭院，第二次经过时每一颗转弯音都被赋予更细腻的明暗光影。",
                "desc_en": "Walking the sunlit turn a second time, subtle dynamic shading makes every ornament glow from within.",
                "focus": "留意第 13–15 柱一连串如珍珠串联般均匀透亮的音群",
                "focus_en": "Marvel at the liquid pearl-like evenness through Pillars 13–15",
            },
            {
                "pass": "B1",
                "pillar": 17,
                "title": "暗夜微澜 · 步入小调的深邃幽谷",
                "title_en": "Nocturnal Heart · Drifting into Velvet Minor Depths",
                "desc": "154.0 秒跨过中轴，色彩骤然变得幽暗深情！第 21–24 柱在 E 小调与半音叹息中触碰全曲最柔软的心房。",
                "desc_en": "Crossing into B1 at 154.0s, shadows gather deeply: Pillars 21–24 ache with poignant chromatic minor beauty.",
                "focus": "听第 21 柱起突然涌上心头的那股温柔酸楚的夜曲氛围",
                "focus_en": "Feel the heart-catching turn into poignant minor nocturne around Pillar 21",
            },
            {
                "pass": "B1",
                "pillar": 25,
                "title": "云端破晓 · 从幽谷重新浮向星光",
                "title_en": "Clearing Skies · Floating Back Into Starlight",
                "desc": "穿过小调幽谷后，银笛旋律乘着一串串轻盈向上的琶音，重新回到澄明温暖的 G 大调夜空。",
                "desc_en": "Emerging from minor shadow, ascending arpeggio filigree lifts the melody back into serene G-major air.",
                "focus": "感受阴霾散开、光线一寸寸重新透进来的释然感",
                "focus_en": "Sense the gentle clearing of clouds as G major returns",
            },
            {
                "pass": "B2",
                "pillar": 17,
                "title": "终章祈祷 · 不忍惊破的月下独白",
                "title_en": "Final Prayer · Unbroken Meditation Under Stars",
                "desc": "231.7 秒开启最后一遍后院巡礼，任奫灿的呼吸愈发宽广静穆，仿佛时间已经停止流动。",
                "desc_en": "Entering B2 at 231.7s, Lim stretches time into pure contemplation—every note poised in velvet hush.",
                "focus": "静下心沉浸在这最后八十秒毫无杂念的纯净歌唱里",
                "focus_en": "Surrender completely to these final eighty seconds of suspended song",
            },
            {
                "pass": "B2",
                "pillar": 25,
                "title": "星光隐没 · 在寂静边缘化为一缕轻烟",
                "title_en": "Fading Starlight · Dissolving at the Edge of Silence",
                "desc": "最后八根金柱缓缓落定，银笛余音袅袅消散——然而千万别松懈，下一秒第 14 变奏的惊雷就要炸响！",
                "desc_en": "The final pillars come peacefully to rest in gossamer silence—right before Variation 14's thunderclap explodes!",
                "focus": "品味最后三秒极致宁静与下一首狂飙突进之间的巨大戏剧张力",
                "focus_en": "Savor the hushed final chord before Variation 14 shatters the stillness",
            },
        ],
        "cues": [
            {"pass": "A1", "pillar": 1, "label": "银色长笛在无重力夜空起舞", "label_en": "Weightless Silver Flute Filigree"},
            {"pass": "A2", "pillar": 1, "label": "A2 反复：天际飘来的极弱月光", "label_en": "A2 Repeat: Whispered Moonlight"},
            {"pass": "B1", "pillar": 21, "label": "暗夜幽谷：全曲最柔肠百转的小调叹息", "label_en": "Poignant E-Minor Nocturnal Heart"},
            {"pass": "B2", "pillar": 29, "label": "星光袅袅隐入寂静", "label_en": "Starlight Dissolving into Hush"},
        ],
    },

    14: {
        "code": "Var. 14",
        "code_en": "Var. 14",
        "title": "第十四变奏 · 惊雷号角与焰火狂欢：上半场最高燃的双排键炫技",
        "title_en": "Variation 14 · Trumpet-Trill Fireworks: Wing I's Most Explosive Virtuoso Duel",
        "subtitle": "双排键辉煌托卡塔 · G大调 · 3/4拍 · 双排键（2 Clav.）",
        "subtitle_en": "Brilliant Two-Manual Toccata · G major · 3/4 · Two Manuals (2 Clav.)",
        "category": "virtuoso",
        "triad": 5,
        "canonInterval": None,
        "canonInverted": False,
        "keyMode": "G major",
        "manuals": "2 Clav.",
        "limHighlight": False,
        "noviceHook": (
            "刚从第 13 变奏的月光梦境里醒来，第一秒就是一声低音惊雷颤音，紧接着一发信号弹“嗖”地蹿升三个八度炸在高空！"
            "两只手像两位剑客在全键盘上互飙颤音、飞身越位 192 次，把气氛瞬间点燃到沸点！"
        ),
        "noviceHook_en": (
            "Shattering Variation 13's moonlit hush, a rumbling low mordent fires a rocket across three octaves in the very first "
            "second! Both hands duel with blazing trills, flying scales, and 192 crossings in an all-out pyrotechnic carnival!"
        ),
        "recipe": (
            "这是上半场（第一翼）最后、也最惊心动魄的一首双排键大炫技曲！巴赫把键盘音乐的看家绝活倾囊而出："
            "开头横跨两三个八度的火箭式大跳、双手轮流接力的长串蜂鸣颤音、机关枪般的同音反复敲击，以及在键盘中央疯狂穿梭的 192 次双手越位！"
            "这场灿烂到极致的 G 大调阳光狂欢，正是为了与紧接其后跌入深渊的第 15 变奏（全曲首支小调！）形成撕裂般的明暗反差。"
        ),
        "recipe_en": (
            "The climactic virtuoso showpiece of Wing I! Bach pulls out every stop in the Baroque keyboard arsenal: opening "
            "three-octave rocket leaps, buzzing relay trills passed from hand to hand, machine-gun repeated-note volleys, and "
            "192 daredevil voice crossings! This dazzling G-major carnival builds maximum brilliance right before Variation 15 "
            "plunges the entire work into G-minor darkness for the very first time."
        ),
        "limNote": (
            "整整 2 分 00 秒（119.5 秒）的高能爆发！任奫灿在卡内基舞台上弹出电光石火般的锋芒：无论是第一秒横跨三个八度的精准弹射，"
            "还是 55.2 秒 B1 与 83.5 秒 B2 中段双手交叉啄击琴键的炫目火光，他的颤音密集得像高压电弧，把全场肾上腺素推向顶点！"
        ),
        "limNote_en": (
            "Two minutes (119.5s) of jaw-dropping high-voltage brilliance! From the opening three-octave catapult at 0.0s through "
            "the blazing cross-hand pecking volleys of B1 (55.2s) and B2 (83.5s), Yunchan Lim's trills crackle like electric arcs, "
            "driving Carnegie Hall's adrenaline sky-high just before the abyss of Variation 15 opens."
        ),
        "voicesMeta": [
            {
                "name": "惊雷火箭主攻手",
                "name_en": "Rocket-Leap & Trill Duelist",
                "role": "开局从低音 G2 颤音直接弹射至高音 F♯5，一路喷吐高压电弧般的长颤音与飞驰音阶",
                "role_en": "Catapults from low G2 mordent straight up to F♯5, firing electric trills and hurtling scales",
            },
            {
                "name": "越位交锋对决手",
                "name_en": "Cross-Hand Counter-Volley",
                "role": "与主攻手轮番互换高低阵地（192 次越位），以连珠啄音与奔腾琶音稳守 32 根金柱",
                "role_en": "Trades trills and rapid-fire cross-hand pecking across 192 crossings over the 32 pillars",
            },
        ],
        "stages": [
            {
                "pass": "A1",
                "pillar": 1,
                "title": "火箭升空 · 横跨三八度的惊雷开场",
                "title_en": "Rocket Launch · Three-Octave Thunderclap",
                "desc": "零秒起爆！低音一声短促颤音，瞬间弹射到高空抖响号角长颤音，两只手立刻展开剑光交锋！",
                "desc_en": "Instant detonation: a low G2 mordent vaults three octaves into blazing treble trills and rapid-fire swordplay!",
                "focus": "听前四秒“地底一震—高空炸响”的过山车弹射感",
                "focus_en": "Catch that thrilling 'low rumble → sky-high flare' catapult in the opening bars",
            },
            {
                "pass": "A2",
                "pillar": 1,
                "title": "蜂鸣接力 · 左右手互抛高压颤音",
                "title_en": "A-Repeat · Electric Trill Relay Race",
                "desc": "27.4 秒杀回起点，留意一只手按住嗡嗡蜂鸣的长颤音时，另一只手如何从容上下翻飞跑动。",
                "desc_en": "Blazing back in at 27.4s, hear how one hand sustains a buzzing electric trill while the other races across it.",
                "focus": "听第 9–16 柱颤音在高低音区轮流点燃的火花串",
                "focus_en": "Follow the relay of crackling trills jumping between treble and bass",
            },
            {
                "pass": "B1",
                "pillar": 17,
                "title": "星雨乱啄 · 全场最炫目的双手穿插奇观",
                "title_en": "Meteor Shower · Rapid-Fire Cross-Hand Pecking",
                "desc": "55.2 秒冲入后院，第 21–28 柱出现全曲最奇特的音响：双手高频交叉轮流啄击单音，像漫天流星雨砸落！",
                "desc_en": "Hurtling into B1 at 55.2s, Pillars 21–28 unleash dazzling rapid-fire hand-over-hand pecking like a meteor shower!",
                "focus": "听中段那种像啄木鸟疾速交替敲击玉石般的奇幻颗粒声",
                "focus_en": "Listen for the dazzling rapid-fire pecking texture mid-section",
            },
            {
                "pass": "B2",
                "pillar": 17,
                "title": "烈日巅峰 · 黑暗降临前的最后一束强光",
                "title_en": "Blazing Zenith · Last Burst of Sunlight Before the Abyss",
                "desc": "83.5 秒发起最后总攻，滚滚三十二分音符洪流直冲终点，在最灿烂的 G 大调强音上戛然而止！",
                "desc_en": "Final assault from 83.5s: cascading thirty-second torrents slam into a brilliant G-major close—right at the cliff edge of Var. 15!",
                "focus": "记住结尾这片耀眼阳光——下一秒世界将瞬间坠入 G 小调黑夜！",
                "focus_en": "Hold this blinding G-major sunlight in your ear—next second, G-minor night falls!",
            },
        ],
        "cues": [
            {"pass": "A1", "pillar": 1, "label": "地底惊雷弹射三八度高空颤音", "label_en": "Three-Octave Rocket Mordent & Trill"},
            {"pass": "A2", "pillar": 9, "label": "双手高压电弧颤音接力", "label_en": "High-Voltage Trill Relay"},
            {"pass": "B1", "pillar": 21, "label": "流星雨般的极速双手交叉啄音", "label_en": "Rapid-Fire Cross-Hand Meteor Volley"},
            {"pass": "B2", "pillar": 29, "label": "烈日洪流冲顶收束", "label_en": "Blazing Torrent to the Cliff Edge"},
        ],
    },

    15: {
        "code": "Var. 15",
        "code_en": "Var. 15",
        "title": "第十五变奏 · 反向五度卡农：坠入G小调暗夜与飘散天际的问号",
        "title_en": "Variation 15 · Inverted Canon at the Fifth: G-Minor Night & a Vanishing Question in Thin Air",
        "subtitle": "反向五度卡农 · 行板（Andante） · G小调 · 2/4拍 · 单排键（1 Clav.）",
        "subtitle_en": "Canone alla Quinta in moto contrario · Andante · G minor · 2/4 · 1 Clav.",
        "category": "canon",
        "triad": 5,
        "canonInterval": 5,
        "canonInverted": True,
        "keyMode": "G minor",
        "manuals": "1 Clav.",
        "limHighlight": True,
        "noviceHook": (
            "全曲第一次变天！前面整整十五首都在明媚的 G 大调阳光里，此刻天空突然暗成深邃的 G 小调黑夜。"
            "听两条悲叹的灵魂：一个一步步往深渊沉落，它的镜像倒影却一步步往星空飘升——最后竟然不落回地面，直接悬在半空中消失了！"
        ),
        "noviceHook_en": (
            "For the very first time in the work, sunlight vanishes into G-minor night! Hear two twin souls: as one sighs step "
            "by step downward into shadow, its mirror twin climbs step by step upward into the stars—ending suspended in thin air!"
        ),
        "recipe": (
            "这是整座《哥德堡》上半场（第一翼，第 0–15 章）的终极收官之门！巴赫在此同时亮出三重震撼设计：第一，全曲首次转入阴郁悲悯的 G 小调，"
            "把黄金立柱染上巴洛克“半音悲叹低音”（Lamento bass）的泪光；第二，采用“反向五度卡农”（音程距离 = 5）：领唱声部从 G4 叹息着半音下行，"
            "追随声部晚一小节从高五度的 D5 反向半音攀升，两人在幽暗中交错 252 次；第三，全曲唯一一处“不封顶的开放式结尾”——"
            "最后一拍左手落在低音 G，右手却沿着音阶一直飘向高空 D5（空五度），像一个悬在宇宙夜空里的巨大问号！"
        ),
        "recipe_en": (
            "The monumental closing gate of Wing I! Bach converges three masterstrokes at once: first, the cycle's very first "
            "plunge into tragic G minor, steeping the 32 pillars in chromatic lament; second, an Inverted Canon at the Fifth "
            "(Interval = 5) where the Leader sighs downward from G4 while the Follower climbs upward from D5 in eerie contrary "
            "motion across 252 crossings; third, the most haunting ending in keyboard literature—while the bass sinks to low G, "
            "the upper voice floats steadily upward to vanish on a bare, ungrounded high D5 in open air!"
        ),
        "limNote": (
            "整整 5 分 37 秒（337.1 秒，上半场最漫长深邃的一章）！任奫灿在 2025 卡内基现场把这首行板弹成了灵魂出窍般的暗夜圣咏。"
            "他在 88.1 秒 A2 与 246.2 秒 B2 反复中，让下沉的叹息声部重如铅华，上升的镜像声部轻如青烟；到了最后十秒，"
            "当右手那颗高音 D5 与地底低音拉出空旷孤寂的五度并缓缓消融在卡内基大厅的黑暗里时，全场数千人屏息凝神，久久无人敢动——"
            "上半场就此合上帷幕，等待第 16 变奏法国序曲的黎明号角！"
        ),
        "limNote_en": (
            "Stretching to a hypnotic 5:37 (337.1s—the longest, deepest span of Wing I), Yunchan Lim turns Variation 15 into "
            "a nocturnal vigil at Carnegie Hall. Through A2 (88.1s) and B2 (246.2s), he weights the descending Leader with mortal "
            "grief while letting the inverted Follower float upward like incense smoke; in the final seconds, that bare high open "
            "fifth evaporates into cavernous darkness, leaving two thousand listeners frozen in awe across the threshold of Wing II."
        ),
        "voicesMeta": [
            {
                "name": "深渊叹息领唱（Dux）",
                "name_en": "Sighing Descending Leader (Dux)",
                "role": "从 G4 起步连连半音下沉叹息（G–F–E♭–D），诉说凡间深沉的忧伤",
                "role_en": "Steps downward from G4 in aching chromatic sighs, weighted with mortal sorrow",
            },
            {
                "name": "升空镜像幽魂（Comes）",
                "name_en": "Ascending Mirror Twin a 5th Above (Comes)",
                "role": "从高五度 D5 反向半音攀升，最终挣脱地心引力独自飘向天际高音而去",
                "role_en": "Rises in exact upside-down mirror from D5, breaking free of gravity to vanish aloft at the close",
            },
            {
                "name": "G小调悲叹金柱",
                "name_en": "G-Minor Lament Ground Bass",
                "role": "首次披上小调黑纱的 32 根立柱，以沉重断续的步伐在暗夜深处缓慢跋涉",
                "role_en": "Shrouds the 32 pillars in G-minor shadow with heavy, grieving chromatic footsteps",
            },
        ],
        "stages": [
            {
                "pass": "A1",
                "pillar": 1,
                "title": "夜幕骤降 · 全曲首抹 G 小调幽光",
                "title_en": "Nightfall · First Plunge Into G-Minor Shadow",
                "desc": "刚刚还是第 14 变奏的烈日狂欢，第一声 G 小调低音落下瞬间，世界仿佛跌进深秋寒夜。",
                "desc_en": "Right on the heels of Var. 14's blinding sunlight, the first G-minor bass step plunges the hall into autumn night.",
                "focus": "听高音两声一组“叹—息、叹—息”往下沉，下一秒另一道白影往上升起！",
                "focus_en": "Hear the paired downward sighs answered one bar later by eerie upward steps!",
            },
            {
                "pass": "A1",
                "pillar": 9,
                "title": "撕裂与交融 · 越拉越远的上下两极",
                "title_en": "Diverging Souls · Pulling Toward Sky and Earth",
                "desc": "第 9–16 柱半音摩擦愈发酸楚，一条线拼命往泥土里钻，另一条线拼命往云层里升，张力惊人。",
                "desc_en": "Across Pillars 9–16 poignant chromatic rubs intensify as one line sinks earthward and its twin climbs skyward.",
                "focus": "感受两条旋律背道而驰时胸口被轻轻揪住的深邃感染力",
                "focus_en": "Feel the aching pull as the two mirror voices stretch apart toward opposite poles",
            },
            {
                "pass": "A2",
                "pillar": 1,
                "title": "暗夜重吟 · 青烟般飘渺的第二遍",
                "title_en": "A-Repeat · Incense Smoke in Cavernous Silence",
                "desc": "88.1 秒重返第 1 柱，任奫灿把声音压得比耳语更轻，仿佛在空旷古教堂里听见自己内心的回声。",
                "desc_en": "Returning at 88.1s, Lim drops below a whisper—like solitary footsteps echoing down a dark stone nave.",
                "focus": "留意左手低音八度跳跃时那一下沉甸甸却不刺耳的心跳脉搏",
                "focus_en": "Listen to the hushed, heartbeat-like octave drops in the lamenting ground bass",
            },
            {
                "pass": "A2",
                "pillar": 9,
                "title": "半音迷宫 · 痛楚与慰藉的一体两面",
                "title_en": "Chromatic Labyrinth · Grief and Consolation Intertwined",
                "desc": "在两百多次声部交错中，下行的悲伤与上行的祈祷不断互换高低位置，彼此抚慰。",
                "desc_en": "Weaving through 252 crossings in all, earthly sorrow and upward prayer trade registers in luminous equilibrium.",
                "focus": "听第 14–16 柱暂时停靠在降 B 大调微弱暖光里的片刻喘息",
                "focus_en": "Catch the brief, fragile ray of B-flat warmth before the first half closes",
            },
            {
                "pass": "B1",
                "pillar": 17,
                "title": "深渊核心 · 最凄美的半音哭泣",
                "title_en": "Into the Abyss · Piercing Chromatic Lament",
                "desc": "169.1 秒步入后半程，切分节奏与密集的半音碰撞将悲剧张力推向顶峰，连呼吸都仿佛结了霜。",
                "desc_en": "Entering B1 at 169.1s, syncopated sighs and dense chromatic clashes deepen the nocturnal vigil to its darkest point.",
                "focus": "听第 21–24 柱一连串撕心裂肺却又克制无比的不协和挂留音",
                "focus_en": "Listen around Pillars 21–24 for the most piercing, expressive suspensions of Wing I",
            },
            {
                "pass": "B1",
                "pillar": 25,
                "title": "灵魂初升 · 第一次预演悬空消散",
                "title_en": "First Levitation · Rehearsing the Open-Air Vanishing",
                "desc": "从第 29 柱起，追随声部开始一路拾级而上，第一次在半空中留下未完待续的空灵悬念。",
                "desc_en": "From Pillar 29 onward, the inverted Follower climbs steadily skyward, floating unresolved at the edge of B2.",
                "focus": "听第 32 柱高音不往下收拢、反而往上飘起的奇异失重感",
                "focus_en": "Hear how Pillar 32 refuses to come down—lifting upward before dropping back into B2",
            },
            {
                "pass": "B2",
                "pillar": 17,
                "title": "终极守夜 · 穿越上半场最后的长夜",
                "title_en": "Final Vigil · Crossing the Last Stretch of Night",
                "desc": "246.2 秒最后一次踏入深渊，任奫灿把每一个音符都弹得如同告别，时间被拉成永恒。",
                "desc_en": "Beginning B2 at 246.2s, Lim slows the pulse almost to a standstill, weighing every chromatic step with timeless farewell.",
                "focus": "感受全场两千名听众屏住呼吸等待终局降临的凝固气场",
                "focus_en": "Feel the entire Carnegie Hall audience holding its breath through this final pass",
            },
            {
                "pass": "B2",
                "pillar": 25,
                "title": "飘散天际 · 悬在宇宙黑暗里的空五度问号",
                "title_en": "Vanishing Into Thin Air · The Unanswered Open Fifth",
                "desc": "最后四柱：左手沉入地底 G 音，右手却顺着音阶一步步飘上高空 D5——不回主音、不给三度冷暖，化作一缕青烟消融在半场帷幕中！",
                "desc_en": "Across the final bars, bass sinks to low G while the right hand climbs step by step to bare high D5—evaporating into darkness before Wing II's French Overture!",
                "focus": "闭上眼听最后一颗高音 D5 悬在半空慢慢消失，直到彻底归于无声！",
                "focus_en": "Close your eyes as that solitary high D5 hangs suspended and evaporates into silence!",
            },
        ],
        "cues": [
            {"pass": "A1", "pillar": 1, "label": "骤入 G 小调暗夜：一沉一升的灵魂镜像", "label_en": "G-Minor Nightfall: Sinking & Rising Twins"},
            {"pass": "A2", "pillar": 1, "label": "A2 反复：古教堂耳语般的极弱吟唱", "label_en": "A2 Repeat: Whispered Nocturnal Vigil"},
            {"pass": "B1", "pillar": 21, "label": "深渊核心：凄美至极的半音悲叹", "label_en": "Piercing Chromatic Lament"},
            {"pass": "B2", "pillar": 29, "label": "灵魂升空：高音 D5 悬在黑暗中消融", "label_en": "High Open Fifth Evaporating Into Thin Air"},
        ],
    },
}
