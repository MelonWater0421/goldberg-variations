#!/usr/bin/env python3
"""
Compile aligned 32-track Yunchan Lim Carnegie Hall audio/score cache + bilingual beginner-to-mastery
pedagogical corpus (corpus_part1.py, corpus_part2.py, astrolabe_enrich.py) into window.GOLDBERG_DATA (data.js).
"""
from __future__ import annotations

import json
import sys
from pathlib import Path
import numpy as np

ROOT = Path(__file__).resolve().parent.parent
TOOLS = ROOT / "tools"
CACHE = TOOLS / "score-cache"
sys.path.insert(0, str(TOOLS))

from corpus_part1 import PRIMER, CHAPTERS_0_15
from corpus_part2 import CHAPTERS_16_31, GLOSSARY, SOURCES, THREADS, WORK_META
from astrolabe_enrich import ASTROLABE_GUIDE, HARMONIC_QUADRANTS

CANONICAL_PC_MAJOR = [
    7, 6, 4, 2, 11, 0, 2, 7,
    7, 6, 4, 2, 11, 1, 2, 2,
    2, 11, 0, 11, 7, 6, 11, 4,
    0, 11, 9, 7, 0, 2, 2, 7,
]
CANONICAL_PC_MINOR = [
    7, 6, 3, 2, 10, 0, 2, 7,
    7, 6, 3, 2, 10, 0, 2, 2,
    2, 9, 10, 6, 7, 8, 7, 0,
    0, 10, 8, 7, 0, 2, 2, 7,
]


def resolve_pillar_sec(pillars: list[dict], pass_name: str, pillar_num: int, track_id: int) -> float:
    for p in pillars:
        if p["pass"] == pass_name and p["pillar"] == pillar_num:
            return float(p["sec"])
    raise ValueError(f"Track {track_id:02d}: could not find pass={pass_name!r}, pillar={pillar_num} in aligned pillars")


def extract_skeleton_notes(t: dict) -> list[list]:
    """
    For every played pillar in t['pillars'], locate the exact score note in t['notes']
    that carries Bach's disguised 32-pillar backbone!
    Returns list of [qStart, qDur, midi, voiceIdx, pillarNum, secStart].
    """
    idx = t["id"]
    pcs = CANONICAL_PC_MINOR if idx in (15, 21, 25) else CANONICAL_PC_MAJOR
    pillars = t["pillars"]
    notes = t["notes"]
    bass_vi = t["voiceCount"] - 1
    grid_step = float(t["beatGridQStep"]) or 1.0
    grid_secs = np.array(t["beatGridSecs"], dtype=np.float64)
    grid_qs = np.arange(len(grid_secs), dtype=np.float64) * grid_step

    out = []
    for k, p in enumerate(pillars):
        q0 = float(p["q"])
        q1 = float(pillars[k + 1]["q"]) if k + 1 < len(pillars) else float(t["totalQ"])
        target_pc = pcs[p["pillar"] - 1]
        cands = [n for n in notes if q0 - 0.08 <= n[0] < q1 - 0.02]
        chosen = None
        if cands:
            pc_cands = [n for n in cands if n[2] % 12 == target_pc]
            if pc_cands:
                # Prefer bass voice first if close to downbeat, else closest to downbeat & lowest register
                pc_cands.sort(key=lambda n: (0 if n[3] == bass_vi else 1, round(abs(n[0] - q0), 2), n[2]))
                chosen = pc_cands[0]
            else:
                near = [n for n in cands if abs(n[0] - q0) <= 0.75] or cands
                near.sort(key=lambda n: (0 if n[3] == bass_vi else 1, n[2], abs(n[0] - q0)))
                chosen = near[0]
        if chosen is None:
            chosen = [round(q0, 3), round(max(0.25, q1 - q0), 3), 43, bass_vi]
        sec_st = float(np.interp(chosen[0], grid_qs, grid_secs))
        out.append([
            round(float(chosen[0]), 3),
            round(float(chosen[1]), 3),
            int(chosen[2]),
            int(chosen[3]),
            int(p["pillar"]),
            round(sec_st, 3),
        ])
    return out


def main() -> None:
    aligned = json.loads((CACHE / "aligned_tracks.json").read_text(encoding="utf-8"))
    chapters = {**CHAPTERS_0_15, **CHAPTERS_16_31}
    assert set(chapters.keys()) == set(range(32)), f"Missing chapters: {set(range(32)) - set(chapters.keys())}"
    assert set(ASTROLABE_GUIDE.keys()) == set(range(32)), "ASTROLABE_GUIDE must cover 0..31"

    tracks_out = []
    total_stages = 0
    total_cues = 0

    for t in aligned["tracks"]:
        idx = t["id"]
        ch = chapters[idx]
        ag = ASTROLABE_GUIDE[idx]
        assert len(ch["voicesMeta"]) == t["voiceCount"], (
            f"Track {idx:02d} voicesMeta len {len(ch['voicesMeta'])} != voiceCount {t['voiceCount']}"
        )

        stages_out = []
        for si, stg in enumerate(ch["stages"]):
            sec = resolve_pillar_sec(t["pillars"], stg["pass"], int(stg["pillar"]), idx)
            if stages_out and sec <= stages_out[-1]["start"]:
                sec = round(stages_out[-1]["start"] + 0.12, 3)
            stages_out.append({
                "id": f"t{idx:02d}-s{si+1}",
                "pass": stg["pass"],
                "pillar": int(stg["pillar"]),
                "start": round(sec, 3),
                "title": stg["title"],
                "title_en": stg["title_en"],
                "desc": stg["desc"],
                "desc_en": stg["desc_en"],
                "focus": stg["focus"],
                "focus_en": stg["focus_en"],
            })

        cues_out = []
        for cue in ch["cues"]:
            sec = resolve_pillar_sec(t["pillars"], cue["pass"], int(cue["pillar"]), idx)
            if cues_out and sec <= cues_out[-1]["sec"]:
                sec = round(cues_out[-1]["sec"] + 0.08, 3)
            cues_out.append({
                "pass": cue["pass"],
                "pillar": int(cue["pillar"]),
                "sec": round(sec, 3),
                "label": cue["label"],
                "label_en": cue["label_en"],
            })

        total_stages += len(stages_out)
        total_cues += len(cues_out)
        skeleton_notes = extract_skeleton_notes(t)

        tracks_out.append({
            "id": idx,
            "code": ch["code"],
            "code_en": ch.get("code_en", ch["code"]),
            "title": ch["title"],
            "title_en": ch["title_en"],
            "subtitle": ch["subtitle"],
            "subtitle_en": ch["subtitle_en"],
            "category": ch["category"],
            "triad": ch["triad"],
            "canonInterval": ch["canonInterval"],
            "canonInverted": bool(ch["canonInverted"]),
            "keyMode": ch["keyMode"],
            "manuals": ch["manuals"],
            "limHighlight": bool(ch["limHighlight"]),
            "noviceHook": ch["noviceHook"],
            "noviceHook_en": ch["noviceHook_en"],
            "recipe": ch["recipe"],
            "recipe_en": ch["recipe_en"],
            "limNote": ch["limNote"],
            "limNote_en": ch["limNote_en"],
            "astro": {
                "disguiseStars": int(ag["disguiseStars"]),
                "disguiseType": ag["disguiseType"],
                "disguiseType_en": ag["disguiseType_en"],
                "whereIsTheme": ag["whereIsTheme"],
                "whereIsTheme_en": ag["whereIsTheme_en"],
                "canonDelayQ": ag["canonDelayQ"],
                "canonRule": ag["canonRule"],
                "canonRule_en": ag["canonRule_en"],
                "modSecret": ag["modSecret"],
                "modSecret_en": ag["modSecret_en"],
            },
            "voicesMeta": ch["voicesMeta"],
            "audio": t["audio"],
            "duration": t["duration"],
            "musicStartSec": t["musicStartSec"],
            "musicEndSec": t["musicEndSec"],
            "hasApplause": t["hasApplause"],
            "tuningSemitones": t["tuningSemitones"],
            "meter": t["meter"],
            "voiceCount": t["voiceCount"],
            "voiceCrossings": t["voiceCrossings"],
            "repeatTopology": t["repeatTopology"],
            "meanCosine": t["meanCosine"],
            "totalQ": t["totalQ"],
            "scorePage": t["scorePage"],
            "scoreUrl": t["scoreUrl"],
            "waveform": t["waveform"],
            "pillars": t["pillars"],
            "skeletonNotes": skeleton_notes,
            "beatGridQStep": t["beatGridQStep"],
            "beatGridSecs": t["beatGridSecs"],
            "notes": t["notes"],
            "stages": stages_out,
            "cues": cues_out,
        })

    meta = dict(WORK_META)
    meta["totalTracks"] = len(tracks_out)
    meta["totalStages"] = total_stages
    meta["totalCues"] = total_cues

    payload = {
        "metadata": meta,
        "primer": PRIMER,
        "groundPillars": aligned["groundPillars"],
        "harmonicQuadrants": HARMONIC_QUADRANTS,
        "tracks": tracks_out,
        "threads": THREADS,
        "glossary": GLOSSARY,
        "sources": SOURCES,
    }

    out_js = ROOT / "data.js"
    out_js.write_text(
        "window.GOLDBERG_DATA = " + json.dumps(payload, ensure_ascii=False, separators=(",", ":")) + ";\n",
        encoding="utf-8",
    )
    print(
        f"Built {out_js.name} ({out_js.stat().st_size / 1024 / 1024:.2f} MB): "
        f"32 tracks, {total_stages} stages, {total_cues} cues, "
        f"skeleton_anchors={sum(len(x['skeletonNotes']) for x in tracks_out)}, "
        f"quadrants={len(HARMONIC_QUADRANTS)}"
    )


if __name__ == "__main__":
    main()
