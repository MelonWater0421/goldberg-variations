#!/usr/bin/env python3
"""
Compile aligned 32-track Yunchan Lim Carnegie Hall audio/score cache + bilingual beginner-to-mastery
pedagogical corpus (corpus_part1.py & corpus_part2.py) into window.GOLDBERG_DATA (data.js).
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
TOOLS = ROOT / "tools"
CACHE = TOOLS / "score-cache"
sys.path.insert(0, str(TOOLS))

from corpus_part1 import PRIMER, CHAPTERS_0_15
from corpus_part2 import CHAPTERS_16_31, GLOSSARY, SOURCES, THREADS, WORK_META


def resolve_pillar_sec(pillars: list[dict], pass_name: str, pillar_num: int, track_id: int) -> float:
    for p in pillars:
        if p["pass"] == pass_name and p["pillar"] == pillar_num:
            return float(p["sec"])
    raise ValueError(f"Track {track_id:02d}: could not find pass={pass_name!r}, pillar={pillar_num} in aligned pillars")


def main() -> None:
    aligned = json.loads((CACHE / "aligned_tracks.json").read_text(encoding="utf-8"))
    chapters = {**CHAPTERS_0_15, **CHAPTERS_16_31}
    assert set(chapters.keys()) == set(range(32)), f"Missing chapters: {set(range(32)) - set(chapters.keys())}"

    tracks_out = []
    total_stages = 0
    total_cues = 0

    for t in aligned["tracks"]:
        idx = t["id"]
        ch = chapters[idx]
        assert len(ch["voicesMeta"]) == t["voiceCount"], (
            f"Track {idx:02d} voicesMeta len {len(ch['voicesMeta'])} != voiceCount {t['voiceCount']}"
        )

        stages_out = []
        for si, stg in enumerate(ch["stages"]):
            sec = resolve_pillar_sec(t["pillars"], stg["pass"], int(stg["pillar"]), idx)
            if stages_out and sec <= stages_out[-1]["start"]:
                sec = round(stages_out[-1]["start"] + 0.12, 3)
            stages_out.append({
                "id": f"t{idx:02d}-s{si+1}",
                "pass": stg["pass"],
                "pillar": int(stg["pillar"]),
                "start": round(sec, 3),
                "title": stg["title"],
                "title_en": stg["title_en"],
                "desc": stg["desc"],
                "desc_en": stg["desc_en"],
                "focus": stg["focus"],
                "focus_en": stg["focus_en"],
            })

        cues_out = []
        for ci, cue in enumerate(ch["cues"]):
            sec = resolve_pillar_sec(t["pillars"], cue["pass"], int(cue["pillar"]), idx)
            if cues_out and sec <= cues_out[-1]["sec"]:
                sec = round(cues_out[-1]["sec"] + 0.08, 3)
            cues_out.append({
                "pass": cue["pass"],
                "pillar": int(cue["pillar"]),
                "sec": round(sec, 3),
                "label": cue["label"],
                "label_en": cue["label_en"],
            })

        total_stages += len(stages_out)
        total_cues += len(cues_out)

        tracks_out.append({
            "id": idx,
            "code": ch["code"],
            "code_en": ch.get("code_en", ch["code"]),
            "title": ch["title"],
            "title_en": ch["title_en"],
            "subtitle": ch["subtitle"],
            "subtitle_en": ch["subtitle_en"],
            "category": ch["category"],
            "triad": ch["triad"],
            "canonInterval": ch["canonInterval"],
            "canonInverted": bool(ch["canonInverted"]),
            "keyMode": ch["keyMode"],
            "manuals": ch["manuals"],
            "limHighlight": bool(ch["limHighlight"]),
            "noviceHook": ch["noviceHook"],
            "noviceHook_en": ch["noviceHook_en"],
            "recipe": ch["recipe"],
            "recipe_en": ch["recipe_en"],
            "limNote": ch["limNote"],
            "limNote_en": ch["limNote_en"],
            "voicesMeta": ch["voicesMeta"],
            "audio": t["audio"],
            "duration": t["duration"],
            "musicStartSec": t["musicStartSec"],
            "musicEndSec": t["musicEndSec"],
            "hasApplause": t["hasApplause"],
            "meter": t["meter"],
            "voiceCount": t["voiceCount"],
            "voiceCrossings": t["voiceCrossings"],
            "repeatTopology": t["repeatTopology"],
            "meanCosine": t["meanCosine"],
            "totalQ": t["totalQ"],
            "scorePage": t["scorePage"],
            "scoreUrl": t["scoreUrl"],
            "waveform": t["waveform"],
            "pillars": t["pillars"],
            "beatGridQStep": t["beatGridQStep"],
            "beatGridSecs": t["beatGridSecs"],
            "notes": t["notes"],
            "stages": stages_out,
            "cues": cues_out,
        })

    meta = dict(WORK_META)
    meta["totalTracks"] = len(tracks_out)
    meta["totalStages"] = total_stages
    meta["totalCues"] = total_cues

    payload = {
        "metadata": meta,
        "primer": PRIMER,
        "groundPillars": aligned["groundPillars"],
        "tracks": tracks_out,
        "threads": THREADS,
        "glossary": GLOSSARY,
        "sources": SOURCES,
    }

    out_js = ROOT / "data.js"
    out_js.write_text(
        "window.GOLDBERG_DATA = " + json.dumps(payload, ensure_ascii=False, separators=(",", ":")) + ";\n",
        encoding="utf-8",
    )
    print(
        f"Built {out_js.name} ({out_js.stat().st_size / 1024 / 1024:.2f} MB): "
        f"32 tracks, {total_stages} stages, {total_cues} cues, "
        f"{len(GLOSSARY)} glossary terms, {len(THREADS)} threads."
    )


if __name__ == "__main__":
    main()
